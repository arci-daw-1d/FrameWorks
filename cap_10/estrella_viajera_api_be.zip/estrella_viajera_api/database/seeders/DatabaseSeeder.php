<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        User::factory()->create([
            'name' => 'a',
            'email' => 'a@a',
            'password' => bcrypt('a'),
            'role' => 'admin',
        ]);
        User::factory()->create([
            'name' => 'b',
            'email' => 'b@b',
            'password' => bcrypt('b'),
        ]);
        User::factory()->create([
            'name' => 'c',
            'email' => 'c@c',
            'password' => bcrypt('c'),
        ]);
        User::factory()->create([
            'name' => 'd',
            'email' => 'd@d',
            'password' => bcrypt('d'),
        ]);
        User::factory()->create([
            'name' => 'u',
            'email' => 'u@u',
            'password' => bcrypt('u'),
        ]);
    }
}
