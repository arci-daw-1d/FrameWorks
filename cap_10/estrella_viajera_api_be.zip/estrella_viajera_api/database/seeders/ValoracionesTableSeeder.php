<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ValoracionesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        \DB::table('valoraciones')->insert([
            [
                'puntuacion' => 1,
                'comentario' => 'Buen viaje',
                'fecha_valoracion' => '2023-10-01',
                'user_id' => 1,
                'destino_id' => 1,
            ],
            [
                'puntuacion' => 1,
                'comentario' => 'Mal viaje',
                'fecha_valoracion' => '2023-10-02',
                'user_id' => 2,
                'destino_id' => 2,
            ],
            [
                'puntuacion' => 3,
                'comentario' => 'Regular viaje',
                'fecha_valoracion' => '2023-10-03',
                'user_id' => 3,
                'destino_id' => 3,
            ],
            [
                'puntuacion' => 4,
                'comentario' => 'Muy buen viaje',
                'fecha_valoracion' => '2023-10-04',
                'user_id' => 4,
                'destino_id' => 4,
            ],
            [
                'puntuacion' => 5,
                'comentario' => 'Excelente viaje',
                'fecha_valoracion' => '2023-10-05',
                'user_id' => 5,
                'destino_id' => 5,
            ],
        ]);
    }
}
