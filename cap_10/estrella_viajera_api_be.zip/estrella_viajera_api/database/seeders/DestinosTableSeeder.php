<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DestinosTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        \DB::table('destinos')->insert([
            [
                'nombre' => 'Luna',
                'descripcion' => 'Descripción viaje a la Luna orbital',
                'precio' => 500,
                'tipo' => 'ORBITAL',
                'imagen_url' => 'cancun.jpg',
                'duracion_viaje' => 7,
                'plazas_disponibles' => 10,
            ],
            [
                'nombre' => 'Marte',
                'descripcion' => 'Descripción viaje a Marte',
                'precio' => 800,
                'tipo' => 'ORBITAL',
                'imagen_url' => 'paris.jpg',
                'duracion_viaje' => 17,
                'plazas_disponibles' => 10,
            ],
            [
                'nombre' => 'Luna',
                'descripcion' => 'Descripción viaje a la Luna llegando a la Luna',
                'precio' => 1200,
                'tipo' => 'LUNAR',
                'imagen_url' => 'tokio.jpg',
                'duracion_viaje' => 27,
                'plazas_disponibles' => 5,
            ],
            [
                'nombre' => 'Saturno',
                'descripcion' => 'Descripción viaje a Saturno',
                'precio' => 1500,
                'tipo' => 'ORBITAL',
                'imagen_url' => 'londres.jpg',
                'duracion_viaje' => 37,
                'plazas_disponibles' => 7,
            ],
            [
                'nombre' => 'Paseo por las nuebes',
                'descripcion' => 'Viaje a baja altura',
                'precio' => 2000,
                'tipo' => 'OTRO',
                'imagen_url' => 'newyork.jpg',
                'duracion_viaje' => 47,
                'plazas_disponibles' => 17,
            ],
        ]);
    }
}
