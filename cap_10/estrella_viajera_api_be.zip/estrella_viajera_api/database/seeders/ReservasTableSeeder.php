<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ReservasTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        \DB::table('reservas')->insert([
            [
                'fecha_reserva' => '2019-01-01',
                'fecha_viaje' => '2019-01-01',
                'num_personas' => 3,
                'estado' => 'CONFIRMADA',
                'user_id' => 1,
                'destino_id' => 1,
            ],
            [
                'fecha_reserva' => '2019-01-01',
                'fecha_viaje' => '2019-01-01',
                'num_personas' => 3,
                'estado' => 'CONFIRMADA',
                'user_id' => 1,
                'destino_id' => 1,
            ],
            [
                'fecha_reserva' => '2019-02-15',
                'fecha_viaje' => '2019-03-01',
                'num_personas' => 2,
                'estado' => 'CANCELADA',
                'user_id' => 2,
                'destino_id' => 2,
            ],
            [
                'fecha_reserva' => '2019-04-10',
                'fecha_viaje' => '2019-05-20',
                'num_personas' => 4,
                'estado' => 'CANCELADA',
                'user_id' => 3,
                'destino_id' => 3,
            ],
            [
                'fecha_reserva' => '2019-06-05',
                'fecha_viaje' => '2019-07-15',
                'num_personas' => 1,
                'estado' => 'CONFIRMADA',
                'user_id' => 4,
                'destino_id' => 4,
            ],
            [
                'fecha_reserva' => '2019-08-20',
                'fecha_viaje' => '2019-09-10',
                'num_personas' => 5,
                'estado' => 'COMPLETADA',
                'user_id' => 5,
                'destino_id' => 5,
            ],

        ]);
    }
}
