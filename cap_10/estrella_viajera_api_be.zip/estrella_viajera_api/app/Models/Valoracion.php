<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Valoracion extends Model
{
    protected $table = 'Valoraciones';
    protected $fillable = [
        'puntuacion',
        'comentario',
        'fecha_valoracion',
        'user_id',
        'destino_id',
    ];
    public function destino(){
        return $this->belongsTo(Destino::class);
    }
    public function usuario(){
        return $this->belongsTo(User::class, 'user_id');
    }
}
