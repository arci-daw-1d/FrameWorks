<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Reserva extends Model
{
    protected $fillable = [
        'fecha_reserva',
        'fecha_viaje',
        'num_personas',
        'estado',
        'user_id',
        'destino_id',
    ];

    public function destino(){
        return $this->belongsTo(Destino::class);
    }
    public function usuario(){
        return $this->belongsTo(User::class, 'user_id');
    }
}
