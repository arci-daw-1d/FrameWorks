<?php

namespace App\GraphQL\Mutations;

use App\Models\Reserva;
use Illuminate\Support\Facades\DB;


class cancelarReserva {
    public function __invoke($rootValue, array $args)
    {
        $reserva = Reserva::find($args['id']);
        if (is_null($reserva)) {
            return false;
        }
        if ($reserva->estado != 'CONFIRMADA') {
            return false;
        }
        DB::beginTransaction();
        try {
            $reserva->destino->plazas_disponibles += $reserva->num_personas;
            $reserva->destino->save();
            $reserva->delete();
            DB::commit();
            return True;
        } catch (\Exception $e) {
            DB::rollback();
            return false;
        }
    }

}
