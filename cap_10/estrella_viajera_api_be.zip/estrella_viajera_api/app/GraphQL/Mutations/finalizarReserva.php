<?php

namespace App\GraphQL\Mutations;

use App\Models\Reserva;
use App\Models\Valoracion;
use Illuminate\Support\Facades\DB;


class finalizarReserva {
    public function __invoke($rootValue, array $args) {
        $reserva = Reserva::find($args['id']);

        // comporbar que la reserva existe y se puede cerrar
        if (is_null($reserva)) {
            return false;
        }
        if ($reserva->estado != 'CONFIRMADA') {
            return false;
        }
        // Comprobar que la valoracion está en rango
        $valoracion = $args['valoracion'] ?? 1;
        if ($valoracion < 1 || $valoracion > 5) {
            return false;
        }
        $comentario = $args['comentario'] ?? '';
        DB::beginTransaction();
        try {
            Valoracion::create([
                'reserva_id' => $args['id'],
                'puntuacion' => $valoracion,
                'comentario' => $comentario,
                'user_id' => $reserva->user_id,
                'destino_id' => $reserva->destino_id,
            ]);
            $reserva->estado = 'COMPLETADA';
            $reserva->save();
            DB::commit();
            return true;
        } catch (\Exception $e) {
            DB::rollback();
            return false;
        }
    }
}
