<?php declare(strict_types=1);

namespace App\GraphQL\Queries;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Nuwave\Lighthouse\Exceptions\AuthenticationException;

final readonly class Login
{
    /** @param  array{}  $args */
    public function __invoke(null $_, array $args)
    {
        $email = $args['email'];
        $password = $args['password'];

        $user = User::query()->where("email", '=', $email)->first();

        if(!$user || !Hash::check($password, $user->password) || $user->role !== 'admin') {
            throw new AuthenticationException();
        }

        $token = $user->createToken($email)->plainTextToken;

        return $token;
    }
}
