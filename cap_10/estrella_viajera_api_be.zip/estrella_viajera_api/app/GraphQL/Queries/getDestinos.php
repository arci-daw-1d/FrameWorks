<?php

namespace App\GraphQL\Queries;

use App\Models\Destino;


class getDestinos {
    public function __invoke($rootValue, array $args)
    {
        $destino = Destino::all();
        return $destino;
    }

}
