<?php declare(strict_types=1);

namespace App\GraphQL\Queries;
use Illuminate\Support\Facades\Auth;


final readonly class Me
{
    /** @param  array{}  $args */
    public function __invoke(null $_, array $args)
    {
        $user = Auth::guard('graphql_auth')->user();

        return [
            'id' => $user->id??-1,
            'email' => $user->email??'N/A',
        ];
    }
}
