<?php

namespace App\GraphQL\Queries;

use App\Models\Destino;


class getDestinosCount {
    public function __invoke($rootValue, array $args)
    {
        $num_res = Destino::all()->count();

        return $num_res??0;
    }

}
