<?php

namespace App\GraphQL\Queries;

use \App\Models\Destino;


class getDestino {
    public function __invoke($rootValue, array $args)
    {
        $destino = Destino::find($args['id']);
        return $destino;
    }

}
