<?php declare(strict_types=1);

namespace App\GraphQL\Queries;
use App\Models\User;
use Illuminate\Support\Facades\Auth;


final readonly class getUser
{
    /** @param  array{}  $args */
    public function __invoke(null $_, array $args)
    {
        $user = User::find($args['id']);
        if (is_null($user)) {
            return [
                'id' => -1,
                'email' => 'N/A',
                'name' => 'N/A',
            ];
        }
        return [
            'id' => $user->id??-1,
            'email' => $user->email??'N/A',
            'name' => $user->name??'N/A',
        ];
    }
}
