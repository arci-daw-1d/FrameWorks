<?php

namespace App\GraphQL\Queries;

use \App\Models\Reserva;


class getReserva {
    public function __invoke($rootValue, array $args)
    {
        $reserva = Reserva::find($args['id']);
        return $reserva;
    }

}
