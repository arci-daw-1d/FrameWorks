<?php

namespace App\GraphQL\Queries;

use App\Models\Reserva;


class getReservasCount {
    public function __invoke($rootValue, array $args)
    {
        $num_res = Reserva::all()->count();

        return $num_res??0;
    }

}
