<?php

namespace App\GraphQL\Queries;

use App\Models\Reserva;


class getReservas {
    public function __invoke($rootValue, array $args)
    {
        $reservas = Reserva::all();
        return $reservas;
    }

}
