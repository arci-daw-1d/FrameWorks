import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  OnInit, output,
  Output,
  SimpleChange,
  SimpleChanges
} from '@angular/core';
import {Subscription} from 'rxjs';
import {Reserva} from '../interfaces';
import {CommsService} from '../services/comms.service';
import {AuthService} from '../services/auth.service';
import {CurrencyPipe, DatePipe} from '@angular/common';
import {NO_RESERVA_ID} from '../ctes';

@Component({
  selector: 'app-reserva',
  imports: [
    DatePipe,
    CurrencyPipe
  ],
  templateUrl: './reserva.component.html',
  styleUrl: './reserva.component.css'
})
export class ReservaComponent implements OnInit, OnDestroy, OnChanges {
  @Input()reserva_id:number=9;
  @Output() reserva_idChange = new EventEmitter();

  reserva$: Subscription = new Subscription();
  reserva!: Reserva;
  delete_reserva = output<number>();  //Evento de salida
  isRunning: boolean = false;

  constructor(private comm: CommsService, private auth: AuthService) {}

  ngOnChanges(changes: SimpleChanges) {
    if (changes["reserva_id"]) {
      this.isRunning = true;
      this.reserva_id = changes["reserva_id"].currentValue;
      this.reserva$ = this.comm.getReservasById(this.reserva_id, this.auth.getToken()).subscribe(params => {
        if (params.data.getReserva!== undefined) {
          this.reserva = params.data.getReserva;
          this.isRunning = false;
        }
      });
    }
  }

  ngOnInit(): void {
    if (this.reserva_id !== NO_RESERVA_ID) {
      this.reserva$ = this.comm.getReservasById(this.reserva_id, this.auth.getToken()).subscribe(params => {
        if (params.data.getReserva !== undefined) {
          this.reserva = params.data.getReserva;
        }
      });
    }
    else {  //Si no hay reserva_id, se crea una reserva de ejemplo
      this.reserva =  { id: 1, fecha_reserva: new Date(), fecha_viaje: new Date(), num_personas: 2, estado: 'confirmada',
        destino: { id: 1, nombre: 'Playa Paraíso', ubicacion: 'Caribe',
          descripcion: 'Un lugar paradisíaco', tipo: 'playa', duracion_viaje: 7,
          precio: 1500, plazas_disponibles: 10, imagen_url: 'https://example.com/playa.jpg' },
        usuario: { id: 1, email: 'usuario@example.com', name: 'Juan Pérez' }
      }
    }
  }

  ngOnDestroy(): void {
    this.reserva$?.unsubscribe();
  }

  delete_clic() {
    this.delete_reserva.emit(this.reserva_id);
  }
}
