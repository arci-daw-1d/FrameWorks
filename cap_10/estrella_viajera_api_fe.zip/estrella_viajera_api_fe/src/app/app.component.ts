import { Component } from '@angular/core';
import {MenuComponent} from './gui/menu/menu.component';
import {LoginComponent} from './gui/login/login.component';
import {AuthService} from './services/auth.service';
import {ListaReservasComponent} from './lista-reservas/lista-reservas.component';

@Component({
  selector: 'app-root',
  imports: [MenuComponent, LoginComponent, ListaReservasComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'estrella_viajera_api_fe';

  constructor(private auth: AuthService) { }

  isLoggedIn(): boolean {
    return this.auth.isLoggedIn();
  }
}

