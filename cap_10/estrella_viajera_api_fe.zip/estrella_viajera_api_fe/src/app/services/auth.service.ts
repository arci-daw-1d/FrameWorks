import { Injectable } from '@angular/core';
import {CommsService} from './comms.service';
import {Subscription} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private observado: Subscription = new Subscription();
  private isAuthenticated: boolean = false;
  private token: string|boolean = '';
  public isRunning: boolean = false;

  constructor(private comm: CommsService) { }

  login(usuario: string = '', clave:string='') {
    this.isRunning = true;
    this.comm.login(usuario, clave).subscribe( params  => {
      if (params.errors === undefined){
        this.token = params.data.login;
      }
      else {
        this.token = '';
      }
      this.isAuthenticated = this.token !== '';
      this.isRunning = false;
    });
    return this.isAuthenticated;
  }

  logout() {
    this.comm.logout(this.token).subscribe( params  => {
      if (params.data.logout=== undefined){
        alert("Error de desconexión");
      }
    });
    this.isAuthenticated = false;
    this.token = '';
  }

  isLoggedIn(): boolean {
    return this.isAuthenticated;
  }

  getToken(): string|boolean {
    return this.token;
  }
}

