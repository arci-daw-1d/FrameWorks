import {inject, Injectable} from '@angular/core';
import {Observable, of, Subscription} from 'rxjs';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {AuthService} from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class CommsService {
  URL = 'http://localhost/public/graphql';
  private http= inject(HttpClient);

  constructor() { }

  login(usuario: string = '', clave: string = ''): Observable<any> {
    const headers= new HttpHeaders();
    const post_params = {query: " query { login(email:\""+usuario+"\", password:\""+clave+"\")}"};
    return this.http.post(this.URL, post_params, {headers: headers});
  }

  logout(token: string|boolean = ''): Observable<any> {
    const headers= new HttpHeaders().set('Authorization', 'Bearer '+token+'');
    const post_params = { query : " query { logout }" };
    return this.http.post(this.URL, post_params, {headers: headers});
  }

  getReservas(token: string|boolean = ''): Observable<any> {
    const headers= new HttpHeaders().set('Authorization', 'Bearer '+token+'');
    const post_params = { query : " query { getReservas { id, fecha_reserva, fecha_viaje, num_personas, estado destino{nombre}, usuario{name}} }" };
    return this.http.post(this.URL, post_params, {headers: headers});
  }

  getReservasById(id: number = 0, token: string|boolean = ''): Observable<any> {
    const headers = new HttpHeaders().set('Authorization', 'Bearer ' + token + '');
    const post_params = {query: " query { getReserva(id: " + id + ") { id, fecha_reserva, fecha_viaje, num_personas, estado destino{nombre,precio}, usuario{name}} }"};
    return this.http.post(this.URL, post_params, {headers: headers});
  }

  cancelarReserva(id: number = 0, token: string|boolean = ''): Observable<any> {
    const headers = new HttpHeaders().set('Authorization', 'Bearer ' + token + '');
    const post_params = {query: " mutation { cancelarReserva(id: " + id + ") }"};
    return this.http.post(this.URL, post_params, {headers: headers});
  }
}
