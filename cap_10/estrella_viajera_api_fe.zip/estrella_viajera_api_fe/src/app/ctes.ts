export const NO_RESERVA_ID = -1
