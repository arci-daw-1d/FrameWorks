import {Component, OnDestroy, OnInit} from '@angular/core';
import {CommsService} from '../services/comms.service';
import {Reserva} from '../interfaces';
import {Subscription} from 'rxjs';
import {AuthService} from '../services/auth.service';
import {ReservaComponent} from '../reserva/reserva.component';
import {NO_RESERVA_ID} from '../ctes';

@Component({
  selector: 'app-lista-reservas',
  imports: [
    ReservaComponent
  ],
  templateUrl: './lista-reservas.component.html',
  styleUrl: './lista-reservas.component.css'
})
export class ListaReservasComponent implements OnInit, OnDestroy {
  reservas$: Subscription = new Subscription();
  reservas: Reserva[] = [];
  reserva_id = NO_RESERVA_ID;
  isRunning: boolean = false;

  constructor(private comm: CommsService, private auth: AuthService) {}

  ngOnInit(): void {
    this.isRunning = true;
    this.reservas$ = this.comm.getReservas(this.auth.getToken()).subscribe(params => {
      if (params.data.getReservas!== undefined) {
        this.reservas = params.data.getReservas;
        this.reserva_id = this.reservas[0].id;
        this.isRunning = false;
      }
    });
  }

  ngOnDestroy(): void {
    this.reservas$?.unsubscribe();
  }

  seleccionarReseva(reserva_id: number) {
    this.reserva_id = reserva_id;
  }

  onDelete($reserva_id: number) {
    this.isRunning = true;
    this.reservas$ = this.comm.cancelarReserva($reserva_id,this.auth.getToken()).subscribe(params => {
      if (params.data.cancelarReserva === true) {
        this.reservas = this.reservas.filter(reserva => reserva.id !== this.reserva_id);
        alert("Dada de baja correctamente");
      }
      else {
        alert("Error al dar de baja la reserva");
      }
      this.isRunning = false;
    });
  }
}
