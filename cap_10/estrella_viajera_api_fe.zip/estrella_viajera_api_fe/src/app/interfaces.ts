export interface Reserva {
  id: number;
  fecha_reserva: Date;
  fecha_viaje: Date;
  num_personas: number;
  estado: string;
  destino: Destino;
  usuario: User;
}

export interface User {
  id: number,
  email: string,
  name: string
}

export interface Destino {
  id: number,
  nombre: string,
  ubicacion: string,
  descripcion: string,
  tipo: string,
  duracion_viaje: number
  precio: number,
  plazas_disponibles: number,
  imagen_url: string,
}
