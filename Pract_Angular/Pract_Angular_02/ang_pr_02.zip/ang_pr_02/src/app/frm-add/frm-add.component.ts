import {Component, output} from '@angular/core';
import {Producto} from '../datos/producto';
import {FormsModule} from '@angular/forms';

@Component({
  selector: 'app-frm-add',
  imports: [
    FormsModule
  ],
  templateUrl: './frm-add.component.html',
  styleUrl: './frm-add.component.css'
})
export class FrmAddComponent {
  producto: Producto = { id: -1, nombre: '', precio: -1, esta_en_cesta: false };

  on_enviar = output<Producto>();

  clicEnviar() {
    this.on_enviar.emit(this.producto);
  }

}
