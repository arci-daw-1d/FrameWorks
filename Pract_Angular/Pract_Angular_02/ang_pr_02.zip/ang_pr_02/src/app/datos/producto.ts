export interface Producto {
    id: number;
    nombre: string;
    precio: number;
    esta_en_cesta: boolean;
}
