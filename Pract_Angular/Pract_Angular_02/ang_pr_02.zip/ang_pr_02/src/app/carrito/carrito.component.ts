import { Component } from '@angular/core';
import {Producto} from '../datos/producto';
import {ElementoComponent} from '../elemento/elemento.component';

@Component({
  selector: 'app-carrito',
  imports: [
    ElementoComponent
  ],
  templateUrl: './carrito.component.html',
  styleUrl: './carrito.component.css'
})
export class CarritoComponent {
  elementosDelCarrito: Producto[]  = [
    { id: 1, nombre: 'Producto 1', precio: 10.99, esta_en_cesta: true },
    { id: 2, nombre: 'Producto 2', precio: 20.99, esta_en_cesta: true  },
    { id: 4, nombre: 'Producto 4', precio: 40.99, esta_en_cesta: true  },
  ];

  on_delete = (producto: Producto) => {
    this.elementosDelCarrito = this.elementosDelCarrito.filter(p => p.id !== producto.id);
  }
}
