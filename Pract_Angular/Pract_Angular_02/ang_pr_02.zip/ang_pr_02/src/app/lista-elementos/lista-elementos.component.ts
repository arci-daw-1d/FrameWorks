import {Component, output} from '@angular/core';
import {Producto} from '../datos/producto';
import {ElementoComponent} from '../elemento/elemento.component';

@Component({
  selector: 'app-lista-elementos',
  imports: [
    ElementoComponent
  ],
  templateUrl: './lista-elementos.component.html',
  styleUrl: './lista-elementos.component.css'
})
export class ListaElementosComponent {
  elementos: Producto[]  = [
    { id: 1, nombre: 'Producto 1', precio: 10.99, esta_en_cesta: false },
    { id: 2, nombre: 'Producto 2', precio: 20.99, esta_en_cesta: false },
    { id: 3, nombre: 'Producto 3', precio: 30.99, esta_en_cesta: false },
    { id: 4, nombre: 'Producto 4', precio: 40.99, esta_en_cesta: false },
    { id: 5, nombre: 'Producto 5', precio: 50.99, esta_en_cesta: false }
  ];

  on_enviar = output<Producto>();

  clicEnviar(producto: Producto) {
    const maxId = Math.max(...this.elementos.map(e => e.id));
    this.on_enviar.emit(producto);
  }
}
