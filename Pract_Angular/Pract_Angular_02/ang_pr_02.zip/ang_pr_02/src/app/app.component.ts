import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import {ListaElementosComponent} from './lista-elementos/lista-elementos.component';
import {CarritoComponent} from './carrito/carrito.component';
import {FrmAddComponent} from './frm-add/frm-add.component';
import {Producto} from './datos/producto';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, ListaElementosComponent, CarritoComponent, FrmAddComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'ang_pr_02';

  handle_addProductoLista(producto: Producto) {
    alert(`Añadiendo a la lista ${producto.precio} ${producto.nombre} ${producto.esta_en_cesta}!`);
  }
  handle_addProductoCarrito(producto: Producto) {
    alert(`Añadiendo al carrito ${producto.precio} ${producto.nombre} ${producto.esta_en_cesta}!`);
  }
}
