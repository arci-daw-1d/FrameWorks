import { Component } from '@angular/core';
import {RouterOutlet} from '@angular/router';
import {ListaCitasComponent} from '../lista-citas/lista-citas.component';

@Component({
  selector: 'app-index-citas',
  imports: [
    RouterOutlet,
    ListaCitasComponent
  ],
  templateUrl: './index-citas.component.html',
  styleUrl: './index-citas.component.css'
})
export class IndexCitasComponent {

}
