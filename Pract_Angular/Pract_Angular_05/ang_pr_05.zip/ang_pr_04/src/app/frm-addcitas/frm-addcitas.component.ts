import { Component } from '@angular/core';
import {DatePipe} from '@angular/common';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {ListaCitasComponent} from '../lista-citas/lista-citas.component';
import {DataService} from '../data.service';

@Component({
  selector: 'app-frm-addcitas',
  imports: [
    ReactiveFormsModule,
  ],
  templateUrl: './frm-addcitas.component.html',
  styleUrl: './frm-addcitas.component.css'
})
export class FrmAddcitasComponent {
  formulario= new FormGroup({
    nombre: new FormControl('Nombre', {nonNullable: true, validators: Validators.required} ),
    fecha: new FormControl( new Date().toISOString().slice(0, 10), {nonNullable: true, validators: Validators.required} ),
    motivo: new FormControl('Texto cita', {nonNullable: true, validators: Validators.required} ),
  });

  constructor(private data: DataService ) { }


  onEnviar() {
    this.data.addCita(this.formulario.controls.nombre.value, new Date(this.formulario.controls.fecha.value),this.formulario.controls.motivo.value)
    alert("Grabado correctamente");
    this.formulario.reset();
  }

  onReset() {
    this.formulario.reset();
  }
}
