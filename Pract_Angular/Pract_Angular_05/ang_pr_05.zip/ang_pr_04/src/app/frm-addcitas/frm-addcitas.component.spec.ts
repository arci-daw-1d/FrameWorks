import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FrmAddcitasComponent } from './frm-addcitas.component';

describe('FrmAddcitasComponent', () => {
  let component: FrmAddcitasComponent;
  let fixture: ComponentFixture<FrmAddcitasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FrmAddcitasComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FrmAddcitasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
