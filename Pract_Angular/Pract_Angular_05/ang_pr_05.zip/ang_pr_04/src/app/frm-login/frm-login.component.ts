import {Component, ElementRef, ViewChild} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {AuthService} from '../auth.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-frm-login',
  imports: [
    FormsModule
  ],
  templateUrl: './frm-login.component.html',
  styleUrl: './frm-login.component.css'
})
export class FrmLoginComponent {
  password: string = '';
  username: string = '';
  @ViewChild('frmLogin', { static: true }) frmLogin!: ElementRef;

  constructor(private auth: AuthService, private router: Router) { }

  login() {
    this.auth.login(this.username, this.password);
    return this.router.navigate(['/']);
  }

  reset() {
    this.frmLogin.nativeElement.reset();
  }
}
