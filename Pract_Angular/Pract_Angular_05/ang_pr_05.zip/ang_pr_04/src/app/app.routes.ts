import { Routes } from '@angular/router';
import {PresentacionComponent} from './presentacion/presentacion.component';
import {BienvenidaComponent} from './bienvenida/bienvenida.component';
import {authGuard} from './auth.guard';
import {FrmLoginComponent} from './frm-login/frm-login.component';
import {FrmAddcitasComponent} from './frm-addcitas/frm-addcitas.component';

export const routes: Routes = [
  {path: 'bienvenida', component: BienvenidaComponent, canActivate: [authGuard]},
  {path: 'home', component: PresentacionComponent},
  {path: 'citas',loadChildren: () => import('./citas.routes')},
  {path: 'login', component: FrmLoginComponent},
  {path: 'add_citas', component: FrmAddcitasComponent},
  {path: '', redirectTo: 'home', pathMatch: 'full'},
  {path: '**', redirectTo: 'home'}
];
