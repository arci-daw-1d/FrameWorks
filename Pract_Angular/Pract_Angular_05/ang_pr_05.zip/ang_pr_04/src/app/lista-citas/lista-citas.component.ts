import {Component, OnInit} from '@angular/core';
import {Cita} from '../cita';
import {AuthService} from '../auth.service';
import {DataService} from '../data.service';
import {ActivatedRoute, Router, RouterLink, RouterOutlet} from '@angular/router';
import {Observable, of, switchMap} from 'rxjs';
import {FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators} from '@angular/forms';

@Component({
  selector: 'app-lista-citas',
  imports: [
    RouterLink,
    FormsModule,
    ReactiveFormsModule
  ],
  templateUrl: './lista-citas.component.html',
  styleUrl: './lista-citas.component.css'
})
export class ListaCitasComponent {
  title: string = 'Lista de Productos';
  citas: Cita[] = [];
  citas_all: Cita[] = [];
  productoSeleccionado: Cita | null = null;

  formulario= new FormGroup({
    fechaIni: new FormControl(new Date().toISOString().slice(0, 10), {nonNullable: true, validators: Validators.required} ),
    fechaFin: new FormControl( new Date().toISOString().slice(0, 10), {nonNullable: true, validators: Validators.required} ),
  });

  onEnviar() {
    this.filtrarCitas(this.formulario.controls.fechaIni.value||null, this.formulario.controls.fechaFin.value||null)
  }

  onReset() {
    this.formulario.reset();
    this.filtrarCitas(null, null)
  }

  constructor(private auth: AuthService, private data: DataService, private route: ActivatedRoute, private router: Router) {
    this.citas = data.getCitas();
    this.citas_all = data.getCitas();
  }

  seleccionarProducto(producto: Cita): void {
    if (this.productoSeleccionado !== producto && this.productoSeleccionado !== null) {
      this.productoSeleccionado.seleccionado = false;
    }
    this.productoSeleccionado = producto;
    this.productoSeleccionado.seleccionado = true;
  }

  findProducto(id: number): Cita|null {
    return this.data.getCita(id)|| null;
  }


  private filtrarCitas(fechaIni: string|null, fechaFin: string|null) {
    if (fechaIni!== null && fechaFin !== null) {
      this.citas = this.citas_all.filter((cita) => {
        const fecha =  (cita.fecha.toISOString().slice(0, 10));
        return fecha >= fechaIni && fecha <= fechaFin;
      });
    }
    else{
      this.citas = this.citas_all;
    }
    return this.router.navigate(['citas']);
  }
}
