import { Injectable } from '@angular/core';
import {Cita} from './cita';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor() { }
  private citas: Cita[] = [
    {
      id: 1,
      nombre: 'Juan Perez',
      fecha: new Date('2023-10-01'),
      motivo: 'Consulta General',
      seleccionado: false
    },
    {
      id: 2,
      nombre: 'Maria Lopez',
      fecha: new Date(),
      motivo: 'Chequeo de rutina',
      seleccionado: false

    },
    {
      id: 3,
      nombre: 'Carlos Sanchez',
      fecha: new Date(),
      motivo: 'Consulta de seguimiento',
      seleccionado: false

    },
    {
      id: 4,
      nombre: 'Ana Torres',
      fecha: new Date(),
      motivo: 'Consulta de emergencia',
      seleccionado: false

    },
    {
      id: 5,
      nombre: 'Luis Garcia',
      fecha: new Date(),
      motivo: 'Consulta de alergias',
      seleccionado: false
    }
  ];

  getCitas(): Cita[]{
    return this.citas;
  }

  getCitasByDate(fechaInicial: Date, fechaFinal: Date): Cita[] {
    const citasFiltradas: Cita[] = this.citas.filter(cita => {
      const fechaCita = new Date(cita.fecha);
      return fechaCita >= fechaInicial && fechaCita <= fechaFinal;
    });
    return citasFiltradas;
  }

  getCita(id:number): Cita|null{
    const cita: Cita|null = this.citas.find(cita => cita.id === id) || null;
    return cita;
  }

  addCita(nombre:string, fecha: Date, motivo: string): void {
    let cita: Cita = {
      id:this.getNextIdCita(),
      nombre:nombre,
      fecha:fecha,
      motivo:motivo,
      seleccionado:false
    }
    this.citas.push(cita);
  }

  private getNextIdCita() {
    return this.citas.length > 0 ? Math.max(...this.citas.map(cita => cita.id)) + 1 : 1;
  }
}
