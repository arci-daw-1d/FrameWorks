import {IndexCitasComponent} from './index-citas/index-citas.component';
import {DetalleCitaComponent} from './detalle-cita/detalle-cita.component';
import {ListaCitasComponent} from './lista-citas/lista-citas.component';

export default [
  {
    path: '',
    component: IndexCitasComponent,
    children: [
      {path: ':id', component: DetalleCitaComponent },
    ]
  }];
