import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private isAuthenticated: boolean = false;
  constructor() { }

  login(usuario: string = '', clave:string='') {
    if (usuario.toUpperCase()==='A' && clave.toUpperCase()==='A') {
      this.isAuthenticated = true;
      return;
    }
    this.isAuthenticated = false;
  }
  logout() {
    this.isAuthenticated = false;
  }
  isLoggedIn(): boolean {
    return this.isAuthenticated;
  }
}
