import {Component, Input, output} from '@angular/core';
import {Producto} from '../datos/producto';
import {CurrencyPipe} from '@angular/common';

@Component({
  selector: 'app-elemento',
  imports: [
    CurrencyPipe
  ],
  templateUrl: './elemento.component.html',
  styleUrl: './elemento.component.css'
})
export class ElementoComponent{
  @Input({required: true}) producto: Producto = { id: -1, nombre: '', precio: -1, esta_en_cesta: false };
  delete = output<Producto>();
  addtocart = output<Producto>();

  on_delete() {
    this.delete.emit(this.producto);
  }

  on_addtocart() {
    this.addtocart.emit(this.producto);
  }
}
