import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FrmAddComponent } from './frm-add.component';

describe('FrmAddComponent', () => {
  let component: FrmAddComponent;
  let fixture: ComponentFixture<FrmAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FrmAddComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FrmAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
