import { Component } from '@angular/core';
import {Producto} from '../datos/producto';
import {ElementoComponent} from '../elemento/elemento.component';
import {CarritoService} from '../services/carrito.service';
import {CurrencyPipe} from '@angular/common';

@Component({
  selector: 'app-carrito',
  imports: [
    ElementoComponent,
    CurrencyPipe
  ],
  templateUrl: './carrito.component.html',
  styleUrl: './carrito.component.css'
})
export class CarritoComponent {
  elementosDelCarrito: Producto[]  = [
    { id: 1, nombre: 'Producto 1', precio: 10.99, esta_en_cesta: true },
    { id: 2, nombre: 'Producto 2', precio: 20.99, esta_en_cesta: true  },
    { id: 4, nombre: 'Producto 4', precio: 40.99, esta_en_cesta: true  },
  ];

  sumaTotal: number = 0;

  on_delete = (producto: Producto) => {
    const index = this.elementosDelCarrito.indexOf(producto, 0);
    const x = this.elementosDelCarrito.splice(index, 1);
    this.sumaTotal -= producto.precio;
    //this.elementosDelCarrito = this.elementosDelCarrito.filter(p => p.id !== producto.id);
  }

  constructor(private dataService: CarritoService) {
    for (let elemento of this.elementosDelCarrito) {
      this.sumaTotal += elemento.precio;
    }
  }

  private add_producto(producto: Producto) {
    this.elementosDelCarrito.push(producto);
    this.sumaTotal += producto.precio;
  }
  ngOnInit() {
    this.dataService.addCarritoObservable.subscribe(
      producto => {
        let producto_copia: Producto = {...producto};
        producto_copia.esta_en_cesta = true;
        this.add_producto(producto_copia);
      }
    );
  }
}
