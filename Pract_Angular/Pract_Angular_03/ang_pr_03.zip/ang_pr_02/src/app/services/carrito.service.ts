import { Injectable } from '@angular/core';
import {Subject} from 'rxjs';
import {Producto} from '../datos/producto';

@Injectable({
  providedIn: 'root',
})
export class CarritoService {
  private addCarritoSubject = new Subject<Producto>()
  addCarritoObservable = this.addCarritoSubject.asObservable();
  constructor() { }
  push_carrito(producto: Producto) {
    this.addCarritoSubject.next(producto);
  }
}
