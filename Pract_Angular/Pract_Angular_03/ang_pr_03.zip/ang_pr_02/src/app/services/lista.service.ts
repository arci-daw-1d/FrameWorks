import { Injectable } from '@angular/core';
import {Subject} from 'rxjs';
import {Producto} from '../datos/producto';

@Injectable({
  providedIn: 'root'
})
export class ListaService {
  private addListaSubject = new Subject<Producto>()
  addListaObservable = this.addListaSubject.asObservable();

  constructor() { }

  push_lista(producto: Producto) {
    this.addListaSubject.next(producto);
  }
}
