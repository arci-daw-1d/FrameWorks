import {Component, output} from '@angular/core';
import {Producto} from '../datos/producto';
import {ElementoComponent} from '../elemento/elemento.component';
import {CarritoService} from '../services/carrito.service';
import {ListaService} from '../services/lista.service';

@Component({
  selector: 'app-lista-elementos',
  imports: [
    ElementoComponent
  ],
  templateUrl: './lista-elementos.component.html',
  styleUrl: './lista-elementos.component.css'
})
export class ListaElementosComponent {
  elementos: Producto[]  = [
    { id: 1, nombre: 'Producto 1', precio: 10.99, esta_en_cesta: false },
    { id: 2, nombre: 'Producto 2', precio: 20.99, esta_en_cesta: false },
    { id: 3, nombre: 'Producto 3', precio: 30.99, esta_en_cesta: false },
    { id: 4, nombre: 'Producto 4', precio: 40.99, esta_en_cesta: false },
    { id: 5, nombre: 'Producto 5', precio: 50.99, esta_en_cesta: false }
  ];

  on_enviar = output<Producto>();

  constructor(private dataService_carrito: CarritoService,
              private dataService_lista: ListaService) { }

  clicEnviar(producto: Producto) {
    const maxId = Math.max(...this.elementos.map(e => e.id));
    //this.on_enviar.emit(producto);
    this.dataService_carrito.push_carrito(producto);
  }

  ngOnInit() {
    this.dataService_lista.addListaObservable.subscribe(
      producto => {
        //Ver qué pasa si quitamos la copia al añadir, modificar el formulario tras añadir
        let producto_copia: Producto = {...producto};
        producto_copia.esta_en_cesta = false;
        this.add_producto(producto_copia);
      }
    );
  }
  private add_producto(producto: Producto) {
      this.elementos.push(producto);
    }
}
