export interface Cita {
  id: number;
  nombre: string;
  fecha: Date;
  motivo: string;
  seleccionado: boolean;
}
