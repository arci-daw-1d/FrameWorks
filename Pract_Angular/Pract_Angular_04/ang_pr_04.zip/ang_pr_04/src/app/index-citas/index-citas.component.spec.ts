import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IndexCitasComponent } from './index-citas.component';

describe('IndexCitasComponent', () => {
  let component: IndexCitasComponent;
  let fixture: ComponentFixture<IndexCitasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [IndexCitasComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IndexCitasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
