import {Component, OnInit} from '@angular/core';
import {Observable, of, switchMap} from 'rxjs';
import {Cita} from '../cita';
import {DataService} from '../data.service';
import {ActivatedRoute} from '@angular/router';
import {DatePipe} from '@angular/common';

@Component({
  selector: 'app-detalle-cita',
  imports: [
    DatePipe
  ],
  templateUrl: './detalle-cita.component.html',
  styleUrl: './detalle-cita.component.css'
})
export class DetalleCitaComponent implements OnInit {
  producto$: Observable<Cita>|undefined;
  producto: Cita | null = null;

  constructor(private data: DataService, private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.producto$ = this.route.paramMap.pipe(
      switchMap(params => {
        const producto = this.data.getCita(Number(params.get('id')))||{} as Cita;
        return of(producto);
      })
    );
    this.producto$?.subscribe(params => {
      this.producto = params;
    });
  }
}
