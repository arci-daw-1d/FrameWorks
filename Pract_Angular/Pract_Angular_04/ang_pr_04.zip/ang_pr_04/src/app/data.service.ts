import { Injectable } from '@angular/core';
import {Cita} from './cita';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor() { }
  private citas: Cita[] = [
    {
      id: 1,
      nombre: 'Juan Perez',
      fecha: new Date('2023-10-01'),
      motivo: 'Consulta General',
      seleccionado: false
    },
    {
      id: 2,
      nombre: 'Maria Lopez',
      fecha: new Date(),
      motivo: 'Chequeo de rutina',
      seleccionado: false

    },
    {
      id: 3,
      nombre: 'Carlos Sanchez',
      fecha: new Date(),
      motivo: 'Consulta de seguimiento',
      seleccionado: false

    },
    {
      id: 4,
      nombre: 'Ana Torres',
      fecha: new Date(),
      motivo: 'Consulta de emergencia',
      seleccionado: false

    },
    {
      id: 5,
      nombre: 'Luis Garcia',
      fecha: new Date(),
      motivo: 'Consulta de alergias',
      seleccionado: false
    }
  ];

  getCitas(): Cita[]{
    return this.citas;
  }

  getCita(id:number): Cita|null{
    const cita: Cita|null = this.citas.find(cita => cita.id === id) || null;
    return cita;
  }
}
