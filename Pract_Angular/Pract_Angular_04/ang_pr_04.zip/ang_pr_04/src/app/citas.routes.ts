import {IndexCitasComponent} from './index-citas/index-citas.component';
import {DetalleCitaComponent} from './detalle-cita/detalle-cita.component';

export default [
  {
    path: '',
    component: IndexCitasComponent,
    children: [
      {path: ':id', component: DetalleCitaComponent },
    ]
  }];
