import { Routes } from '@angular/router';
import {PresentacionComponent} from './presentacion/presentacion.component';
import {BienvenidaComponent} from './bienvenida/bienvenida.component';
import {authGuard} from './auth.guard';

export const routes: Routes = [
  {path: 'bienvenida', component: BienvenidaComponent, canActivate: [authGuard]},
  {path: 'home', component: PresentacionComponent},
  {path: 'citas',loadChildren: () => import('./citas.routes')},
  {path: '', redirectTo: 'home', pathMatch: 'full'},
  {path: '**', redirectTo: 'home'}
];
