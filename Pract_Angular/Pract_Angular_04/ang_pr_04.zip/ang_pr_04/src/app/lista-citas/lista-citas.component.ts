import { Component } from '@angular/core';
import {Cita} from '../cita';
import {AuthService} from '../auth.service';
import {DataService} from '../data.service';
import {RouterLink, RouterOutlet} from '@angular/router';

@Component({
  selector: 'app-lista-citas',
  imports: [
    RouterLink
  ],
  templateUrl: './lista-citas.component.html',
  styleUrl: './lista-citas.component.css'
})
export class ListaCitasComponent {
  title: string = 'Lista de Productos';
  citas: Cita[] = [];
  productoSeleccionado: Cita | null = null;

  constructor(private auth: AuthService, private data: DataService) {
    this.citas = data.getCitas();
  }

  seleccionarProducto(producto: Cita): void {
    if (this.productoSeleccionado !== producto && this.productoSeleccionado !== null) {
      this.productoSeleccionado.seleccionado = false;
    }
    this.productoSeleccionado = producto;
    this.productoSeleccionado.seleccionado = true;
  }

  findProducto(id: number): Cita|null {
    return this.data.getCita(id)|| null;
  }

}
