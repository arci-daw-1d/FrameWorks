<!doctype html>
<html>
<head>
    @vite(['resources/css/app.css','resources/js/app.js'])
<body>
<div class="container">
    <div class="row alert alert-primary">
        <h1>This is example from</h1>
    </div>
</div>
</body>
</html>
