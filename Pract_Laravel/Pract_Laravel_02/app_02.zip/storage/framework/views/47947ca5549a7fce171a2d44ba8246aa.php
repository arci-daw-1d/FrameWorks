<!doctype html>
<html>
<head>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
<body>
<div class="container">
    <div class="row alert alert-primary">
        <h1>This is example from</h1>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\pro_rutas\app_02\resources\views/welcome.blade.php ENDPATH**/ ?>