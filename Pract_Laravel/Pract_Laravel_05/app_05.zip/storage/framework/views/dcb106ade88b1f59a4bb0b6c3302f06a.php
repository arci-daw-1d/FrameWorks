<?php $__env->startSection("contenido"); ?>
<?php if(isset($usuario)): ?>
    <h1>Hola <?php echo e($usuario->nombre); ?> con <?php echo e($usuario->edad); ?> años</h1>
<?php else: ?>
    <h1>Hola <?php echo e($nombre); ?> con <?php echo e($edad); ?> años</h1>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.base", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Herd\app_05\resources\views/admin/login/logout.blade.php ENDPATH**/ ?>