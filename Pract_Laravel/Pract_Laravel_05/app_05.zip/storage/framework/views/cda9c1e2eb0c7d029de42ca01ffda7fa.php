<?php $__env->startSection('contenido'); ?>
<p>Welcome to the application. This is a simple Laravel application that demonstrates the use of Blade templates and routing.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Herd\app_05\resources\views/welcome.blade.php ENDPATH**/ ?>