<div class="container">
    <h1>
        LOGO
    </h1>
    <br>
</div>
<?php /**PATH C:\Herd\app_05\resources\views/layouts/logo.blade.php ENDPATH**/ ?>