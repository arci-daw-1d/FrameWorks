<?php $__env->startSection("contenido"); ?>
<?php if($login==1): ?>
Conectado
<?php else: ?>
No conectado
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.base", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Herd\app_05\resources\views/admin/login/login.blade.php ENDPATH**/ ?>