<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get("/login_1", function () {
    return view('admin.login.login',['login' => 1]);
});

Route::get("/login_2", function () {
    return view('admin.login.login',['login' => 0]);
});

Route::get("/logout_1", function () {
    $usuario = (object) ['nombre' => 'Nombre 1', 'edad' => 23];
    return view('admin.login.logout',['usuario' => $usuario]);
});

Route::get("/logout_2", function () {
    $nombre = 'Nombre 2';
    $edad = 25;

    return view('admin.login.logout',compact("nombre", "edad"));
});
