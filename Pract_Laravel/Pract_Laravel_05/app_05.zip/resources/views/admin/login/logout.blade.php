@extends("layouts.base")
@section("contenido")
@isset($usuario)
    <h1>Hola {{ $usuario->nombre }} con {{ $usuario->edad }} años</h1>
@else
    <h1>Hola {{ $nombre }} con {{ $edad }} años</h1>
@endisset
@endsection
