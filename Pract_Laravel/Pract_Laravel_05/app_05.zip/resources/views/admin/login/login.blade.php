@extends("layouts.base")
@section("contenido")
@if($login==1)
Conectado
@else
No conectado
@endif
@endsection
