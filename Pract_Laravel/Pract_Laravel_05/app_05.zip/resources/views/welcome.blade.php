@extends('layouts.base')
@section('contenido')
<p>Welcome to the application. This is a simple Laravel application that demonstrates the use of Blade templates and routing.</p>
@endsection
