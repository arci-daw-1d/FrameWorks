<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MainController;

Route::get('/', [MainController::class, 'index']);
Route::get('/login', [MainController::class, 'login'])->name('login');
Route::post('/login', [MainController::class, 'authenticate']);
Route::get('/logout', [MainController::class, 'logout'])->name('logout');
Route::get('/sin_proteger', [MainController::class, 'sin_proteger'])->name('sin_proteger');
Route::get('/protegido', [MainController::class, 'protegido'])->name('protegido');
