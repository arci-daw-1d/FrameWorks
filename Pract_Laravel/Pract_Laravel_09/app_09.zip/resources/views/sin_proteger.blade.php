
@extends('base')
@section('menu')
    <h1>App 09</h1>
@endsection
@section('contenido')
    <h2>Sin proteger</h2>
    @auth
        <h3>Hola {{ Auth::user()->name }}</h3>
        <p>Tu email es {{ Auth::user()->email }}</p>
    @else
        <h3>Hola invitado</h3>
        <p>Para acceder a esta sección debes iniciar sesión</p>
    @endauth
@endsection
