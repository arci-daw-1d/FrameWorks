
@extends('base')
@section('menu')
    <h1>App 09</h1>
@endsection
@section('contenido')
    <h2>Login</h2>
    @if (count($errors))
    <ul class="errors list-unstyled">
        @foreach($errors->all() as $error)
            <li class="alert alert-warning ">{{ $error }}</li>
        @endforeach
    </ul>
    @endif
    <form method="POST" enctype="multipart/form-data" action="{{ route('login') }}">
        @csrf
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="text" class="form-control" id="email" name="email" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary">Login</button>
    </form>
@endsection
