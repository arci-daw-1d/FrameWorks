
@extends('base')
@section('menu')
    <h1>App 09</h1>
@endsection
@section('contenido')
    <h2Protegido</h2>
    @auth
        <h3>Hola {{ Auth::user()->name }}</h3>
        <p>Tu email es {{ Auth::user()->email }}</p>
    @endauth
@endsection
