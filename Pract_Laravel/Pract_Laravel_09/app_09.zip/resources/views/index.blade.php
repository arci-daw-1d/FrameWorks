
@extends('base')
@section('menu')
    <h1>App 09</h1>
@endsection
@section('contenido')
    <h2>Index</h2>
@endsection
