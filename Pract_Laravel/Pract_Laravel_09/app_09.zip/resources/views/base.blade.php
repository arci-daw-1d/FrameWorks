<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

    <!-- Styles / Scripts -->
    @if (file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot')))
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    @endif
</head>
<body>
<div class="container">
    <div class="row alert alert-primary">
        @yield('menu')
    </div>
    <div class="row">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            @auth
                                <a class="nav-link" aria-current="page" href="{{ route('logout') }}">Logout</a>
                            @else
                                <a class="nav-link" aria-current="page" href="{{ route('login') }}">Login</a>
                            @endauth
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('protegido') }}">Protegido</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('sin_proteger') }}">Sin Proteger</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
    <div class="row alert alert-secondary">
        <div class="col-12">
            @yield('contenido')
        </div>
    </div>
</div>


</body>
</html>
