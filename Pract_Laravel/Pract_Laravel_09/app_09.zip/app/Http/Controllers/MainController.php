<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\View\View;

class MainController extends Controller
{
    public function index():View {
        return view('index');
    }

    public function login() {
        return view('login');
    }

    public function authenticate(Request $request) {
        $credentials = $request->only('email', 'password');

        if (auth()->attempt($credentials)) {
            return redirect('/');
        }

        return redirect()->back()->withErrors([
            'errors' => 'The provided credentials do not match our records.',
        ]);
    }

    public function logout() {
        auth()->logout();
        session()->flush();
        session()->regenerate();
        return redirect('/');
    }

    public function sin_proteger() {
        return view('sin_proteger');
    }

    public function protegido() {
        return view('protegido');
    }
}
