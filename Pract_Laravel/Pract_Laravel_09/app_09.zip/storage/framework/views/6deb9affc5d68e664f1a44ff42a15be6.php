<?php $__env->startSection('menu'); ?>
    <h1>App 09</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
    <h2>Sin proteger</h2>
    <?php if(auth()->guard()->check()): ?>
        <h3>Hola <?php echo e(Auth::user()->name); ?></h3>
        <p>Tu email es <?php echo e(Auth::user()->email); ?></p>
    <?php else: ?>
        <h3>Hola invitado</h3>
        <p>Para acceder a esta sección debes iniciar sesión</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Herd\app_09\resources\views/sin_proteger.blade.php ENDPATH**/ ?>