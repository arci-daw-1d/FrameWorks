<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

    <!-- Styles / Scripts -->
    <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php endif; ?>
</head>
<body>
<div class="container">
    <div class="row alert alert-primary">
        <?php echo $__env->yieldContent('menu'); ?>
    </div>
    <div class="row">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <?php if(auth()->guard()->check()): ?>
                                <a class="nav-link" aria-current="page" href="<?php echo e(route('logout')); ?>">Logout</a>
                            <?php else: ?>
                                <a class="nav-link" aria-current="page" href="<?php echo e(route('login')); ?>">Login</a>
                            <?php endif; ?>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('protegido')); ?>">Protegido</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('sin_proteger')); ?>">Sin Proteger</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
    <div class="row alert alert-secondary">
        <div class="col-12">
            <?php echo $__env->yieldContent('contenido'); ?>
        </div>
    </div>
</div>


</body>
</html>
<?php /**PATH C:\Herd\app_09\resources\views/base.blade.php ENDPATH**/ ?>