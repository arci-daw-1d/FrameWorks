<?php $__env->startSection('menu'); ?>
    <h1>App 09</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
    <h2>Index</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Herd\app_09\resources\views/index.blade.php ENDPATH**/ ?>