<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UsuariosController extends Controller
{
    //
    function index () {
        return view('welcome');
    }

    function resultado() {
        return view('resultado');
    }

    function redireccion() {
        return redirect('/resultado');
    }

    function valor_obl($id) {
        return "El valor es {$id}";
    }

    function valor_opt($id=1) {
        return "El valor es {$id}";
    }

    function nombre() {
        return "<p>Nombre</p>";
    }
}
