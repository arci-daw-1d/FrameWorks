<!DOCTYPE html>
@extends('layouts.base')
@section('contenido')
<div class="container">
    <h1>Resultados</h1>
    <p><a href="{{ url('/') }}">Inicio</a> </p>
</div>
@endsection
