<?php $__env->startSection('contenido'); ?>
    <div class="container">
        <h1>Entrada</h1>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Herd\app_04\resources\views/welcome.blade.php ENDPATH**/ ?>