<!DOCTYPE html>

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <h1>Resultados</h1>
    <p><a href="<?php echo e(url('/')); ?>">Inicio</a> </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Herd\app_04\resources\views/resultado.blade.php ENDPATH**/ ?>