<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UsuariosController;

Route::get('/', [UsuariosController::class, 'index']);
Route::get('/resultado', [UsuariosController::class, 'resultado']);
Route::get('/redireccion', [UsuariosController::class, 'redireccion']);
Route::post('/valor_obl/{id}', [UsuariosController::class, 'valor_obl']);
Route::post('/valor_opt/{id?}', [UsuariosController::class, 'valor_opt']);
Route::get('/nombre', [UsuariosController::class, 'nombre'])->name('inicio.nombre');
