<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use function Symfony\Component\String\s;

class MainController extends Controller
{
    public function protegida_1() {
        return "Protegida 1";
    }
    public function protegida_2() {
        return "Protegida 2";
    }
    public function sin_proteger() {
        return view('sin_proteger');
    }
    public function desconectar() {
        auth()->logout();
        session()->flush();
        session()->regenerate();
        return redirect()->route('index');
    }
}
