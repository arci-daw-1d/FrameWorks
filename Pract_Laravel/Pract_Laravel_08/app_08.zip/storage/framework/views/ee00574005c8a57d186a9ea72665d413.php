<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>App 08</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

        <!-- Styles / Scripts -->
        <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
        <?php endif; ?>
    </head>
    <body>
        <div id="app">
            <h1>App 08</h1>
            <p>Auth App</p>
            <table>
                <tr>
                    <td><a href="<?php echo e(route('protegida_1')); ?>">Protegida 1</a></td>
                    <td><a href="<?php echo e(route('protegida_2')); ?>">Protegida 2</a></td>
                    <td><a href="<?php echo e(route('sin_proteger')); ?>">Sin proteger</a></td>
                    <td><a href="<?php echo e(route('desconectar')); ?>">Desconectar</a></td>
                </tr>
            </table>
        </div>
    </body>
</html>
<?php /**PATH C:\Herd\app_08\resources\views/index.blade.php ENDPATH**/ ?>