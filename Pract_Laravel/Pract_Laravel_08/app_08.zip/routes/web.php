<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MainController;

Route::get('/', function () {
    return view('index');
})->name('index');

//Route::get('/protegida_1', [MainController::class,'protegida_1'])->middleware('auth.basic')->name('protegida_1');
//Route::get('/protegida_2', [MainController::class,'protegida_2'])->middleware('auth.basic')->name('protegida_2');
Route::group(['middleware' => 'auth.basic'], function () {
    Route::get('/protegida_1', [MainController::class,'protegida_1'])->name('protegida_1');
    Route::get('/protegida_2', [MainController::class,'protegida_2'])->name('protegida_2');
});

Route::get('/sin_proteger', [MainController::class,'sin_proteger'])->name('sin_proteger');
Route::get('/desconectar', [MainController::class,'desconectar'])->name('desconectar');
