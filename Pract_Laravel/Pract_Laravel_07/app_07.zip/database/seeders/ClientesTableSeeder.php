<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ClientesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        \DB::table('clientes')->insert([
            [
                'telefono_de_contacto' => '1234567890',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'telefono_de_contacto' => '0987654321',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'telefono_de_contacto' => '1122334455',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'telefono_de_contacto' => '5566778899',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'telefono_de_contacto' => '6677889900',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'telefono_de_contacto' => '7788990011',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'telefono_de_contacto' => '8899001122',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'telefono_de_contacto' => '9900112233',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'telefono_de_contacto' => '0011223344',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'telefono_de_contacto' => '2233445566',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}
