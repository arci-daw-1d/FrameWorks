<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class EmpleadosTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        \DB::table('empleados')->insert([
            [
                'sueldo_bruto' => 3000.00,
                'empresa_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'sueldo_bruto' => 3200.00,
                'empresa_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'sueldo_bruto' => 2800.00,
                'empresa_id' => 2,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'sueldo_bruto' => 3500.00,
                'empresa_id' => 2,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'sueldo_bruto' => 4000.00,
                'empresa_id' => 3,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'sueldo_bruto' => 3100.00,
                'empresa_id' => 3,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'sueldo_bruto' => 2900.00,
                'empresa_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'sueldo_bruto' => 3300.00,
                'empresa_id' => 2,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'sueldo_bruto' => 3600.00,
                'empresa_id' => 3,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'sueldo_bruto' => 3700.00,
                'empresa_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);

    }
}
