<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class Cliente_EmpresaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        \DB::table('cliente_empresa')->insert([
            ['cliente_id' => 1, 'empresa_id' => 1, 'created_at' => now(), 'updated_At' => now()],
            ['cliente_id' => 1, 'empresa_id' => 2, 'created_at' => now(), 'updated_At' => now()],
            ['cliente_id' => 2, 'empresa_id' => 1, 'created_at' => now(), 'updated_At' => now()],
            ['cliente_id' => 3, 'empresa_id' => 1, 'created_at' => now(), 'updated_At' => now()],
            ['cliente_id' => 5, 'empresa_id' => 1, 'created_at' => now(), 'updated_At' => now()],
        ]);

    }
}
