<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class EmpresasTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        \DB::table('empresas')->insert([
            [
                'nombre' => 'Empresa 1',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'nombre' => 'Empresa 2',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'nombre' => 'Empresa 3',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);


    }
}
