<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Empresa extends Model
{
    public function empleados(){
        return $this->hasMany(Empleado::class);
    }
    public function clientes(){
        return $this->belongsToMany(Cliente::class);
    }
}
