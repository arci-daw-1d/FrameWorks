<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Empleado;
use App\Models\Empresa;
use App\Models\Cliente;

class EjemploController extends Controller
{
    public function index()
    {
//        return $this->all_empleados();
//        return $this->all_empleados_from_empresa();
//        return $this->all_empresas();
//        return $this->all_clientess_from_empresa();
//        return $this->gasto_por_mes_from_empresa();
//        return $this->num_empresa();
//        return $this->empleados_entre_sueldo();
//        return $this->empleados_entre_sueldo_from_empresa();
//        return $this->delete_suave_empleado();
//        return $this->all_clientes_sin_borrados();
//        return $this->all_clientes_con_borrados();
//        return $this->delete_empleado();
//        return $this->all_clientes_con_borrados();
//        return $this->all_clientes_solo_borrados_suaves();
//        return $this->new_cliente();
        return $this->mod_cliente();
    }

    public function paginate(){
        $paginator = Empleado::paginate(3);
        return view('paginate', compact('paginator'));
    }

    private function all_empleados(){
        return Empleado::all();
    }

    private function all_empleados_from_empresa() {
        return Empresa::find(1)->empleados;
    }

    private function all_empresas() {
        return Empresa::all();
    }
    private function all_clientess_from_empresa() {
        return Empresa::find(1)->clientes;
    }

    private function gasto_por_mes_from_empresa() {
        return Empresa::find(1)->empleados->sum('sueldo_bruto');
    }

    private function num_empresa() {
        return Empresa::get()->count();
    }

    private function empleados_entre_sueldo() {
        return Empleado::all()->whereBetween('sueldo_bruto', [3000, 3500]);
    }

    private function empleados_entre_sueldo_from_empresa() {
        return Empresa::find(1)->empleados->whereBetween('sueldo_bruto', [3000, 3500]);
    }

    private function delete_suave_empleado(){
        $cliente = Cliente::find(7);
        $cliente->delete();
        return response()->json(['message' => 'Cliente eliminado correctamente']);
    }

    private function all_clientes_sin_borrados() {
        return Cliente::all();
    }

    private function all_clientes_con_borrados() {
        return Cliente::withTrashed()->get();
    }

    private function delete_empleado(){
        $cliente = Cliente::withTrashed()->find(7);
        $cliente->forceDelete();
        return response()->json(['message' => 'Cliente eliminado completamente correctamente']);
    }

    private function all_clientes_solo_borrados_suaves(){
        return Cliente::onlyTrashed()->get();
    }

    private function new_cliente(){
        $cliente = new Cliente();
        $cliente->telefono_de_contacto = "1234567890";
        $cliente->save();
        return response()->json(['message' => 'Cliente creado correctamente']);
    }

    private function mod_cliente(){
        $cliente = Cliente::find(2);
        $cliente->telefono_de_contacto = "9999999999";
        $cliente->save();
        return response()->json(['message' => 'Cliente modificado correctamente']);
    }
}
