<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EjemploController;

Route::get('/', [EjemploController::class, 'index']);
Route::get('/paginate', [EjemploController::class, 'paginate']);

