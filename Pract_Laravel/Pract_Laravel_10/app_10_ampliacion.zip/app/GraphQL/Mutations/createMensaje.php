<?php
namespace App\GraphQL\Mutations;

use App\Models\Mensaje;

class CreateMensaje
{
    public function __invoke($rootValue, array $args)
    {
        $msg = Mensaje::create([
            'cuerpo' => $args['cuerpo'],
            'user_id' => $args['user_id'],
        ]);

        return $msg;
    }
}

