<?php

namespace App\GraphQL\Queries;

use App\Models\Mensaje;


class getMensaje {
    public function __invoke($rootValue, array $args)
    {
        $user = Mensaje::find($args['id']);
        return $user;
    }

}
