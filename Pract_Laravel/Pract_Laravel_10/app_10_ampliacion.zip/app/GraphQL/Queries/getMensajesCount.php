<?php

namespace App\GraphQL\Queries;

use App\Models\Mensaje;


class getMensajesCount {
    public function __invoke($rootValue, array $args)
    {
        $num_msgs = Mensaje::all()->count();

        return $num_msgs??0;
    }

}
