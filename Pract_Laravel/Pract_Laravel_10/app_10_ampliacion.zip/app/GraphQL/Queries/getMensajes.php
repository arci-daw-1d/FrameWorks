<?php

namespace App\GraphQL\Queries;

use App\Models\Mensaje;


class getMensajes {
    public function __invoke($rootValue, array $args)
    {
        $user = Mensaje::all();

        return $user;
    }

}
