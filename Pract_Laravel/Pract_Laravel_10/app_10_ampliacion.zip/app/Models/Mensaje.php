<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Mensaje extends Model
{
    protected $fillable = [
        'id',
        'cuerpo',
        'user_id',
        'created_at',
        'updated_at',
    ];
    public function creador() {
        $this->hasOne(User::class, 'id', 'user_id');
    }
}
