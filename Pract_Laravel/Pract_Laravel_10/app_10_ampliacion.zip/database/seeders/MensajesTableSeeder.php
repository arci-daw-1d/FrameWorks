<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class MensajesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        \DB::table('mensajes')->insert([
            ['cuerpo' => 'Mensaje de prueba 1', 'user_id' => 1, 'created_at' => now(), 'updated_at' => now()],
            ['cuerpo' => 'Mensaje de prueba 2', 'user_id' => 1, 'created_at' => now(), 'updated_at' => now()],
            ['cuerpo' => 'Mensaje de prueba 3', 'user_id' => 1, 'created_at' => now(), 'updated_at' => now()],
            ['cuerpo' => 'Mensaje de prueba 4', 'user_id' => 1, 'created_at' => now(), 'updated_at' => now()],
            ['cuerpo' => 'Mensaje de prueba 5', 'user_id' => 1, 'created_at' => now(), 'updated_at' => now()],
            ['cuerpo' => 'Mensaje de prueba 6', 'user_id' => 1, 'created_at' => now(), 'updated_at' => now()],
            ['cuerpo' => 'Mensaje de prueba 7', 'user_id' => 1, 'created_at' => now(), 'updated_at' => now()],
            ['cuerpo' => 'Mensaje de prueba 8', 'user_id' => 1, 'created_at' => now(), 'updated_at' => now()],
            ['cuerpo' => 'Mensaje de prueba 9', 'user_id' => 1, 'created_at' => now(), 'updated_at' => now()],
        ]);
    }
}
