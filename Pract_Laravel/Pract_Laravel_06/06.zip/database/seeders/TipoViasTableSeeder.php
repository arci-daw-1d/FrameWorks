<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class TipoViasTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        \DB::table('tipovias')->insert([
            [
                'descri' => 'Calle'
            ],
            [
                'descri' => 'Plaza'
            ],
            [
                'descri' => 'Carretera'
            ],
        ]);
    }
}
