<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UsuariosTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        \DB::table('usuarios')->insert([
            [
                'usuario' => 'u',
                'clave' => 'u',
                'tipo' => 1,
                'fechaAlta' => now(),
            ],
            [
                'usuario' => 'a',
                'clave' => 'a',
                'tipo' => 0,
                'fechaAlta' => now(),
            ]
        ]);
    }
}
