<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AlumnosTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        \DB::table('alumnos')->insert([
            [
                'nombre' => 'Juan',
                'apellidos' => 'Pérez García',
                'dni' => '12345678A',
                'fechaNacimiento' => '2000-01-01',
                'tipoVias_id' => 1, // Asegúrate de que este ID exista en la tabla tipovias
                'nombreVia' => 'Gran Vía',
                'numeroVia' => '123',
                'telefono' => '600123456',
                'localidad' => 'Madrid'
            ],
            [
                'nombre' => 'María',
                'apellidos' => 'López Fernández',
                'dni' => '87654321B',
                'fechaNacimiento' => '1998-05-15',
                'tipoVias_id' => 2, // Asegúrate de que este ID exista en la tabla tipovias
                'nombreVia' => 'Plaza Mayor',
                'numeroVia' => '45',
                'telefono' => '600654321',
                'localidad' => 'Barcelona'
            ],
        ]);
    }
}
