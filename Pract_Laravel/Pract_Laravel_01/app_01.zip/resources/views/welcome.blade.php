@extends('layouts.base')
@section('contenido')
<div class="row alert alert-primary">
    <h1>Inicio</h1>
</div>
<div class="rowy">
    <p>Esta es la página de inicio</p>
</div>
<a href="{{ url('/ventas') }}">Ventas</a>
@endsection
