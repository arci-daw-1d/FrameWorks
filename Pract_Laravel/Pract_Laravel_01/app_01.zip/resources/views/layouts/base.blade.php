<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ventas</title>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <ul class="navbar-nav me-auto mb-2">
                    <li class="nav-item">
                        <a href="{{ url('/') }}" class="navbar-brand">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/ventas') }}" class="navbar-brand">Ventas</a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/copyright') }}" class="navbar-brand">CopyRight</a>
                    </li>
                </ul>
            </div>
        </nav>
        <div class="row">
            <div class="col-m9 justify-content">
                @yield('contenido')
            </div>
        </div>
    </div>
    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</body>
</html>
