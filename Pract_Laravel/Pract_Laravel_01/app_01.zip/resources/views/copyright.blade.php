@extends('layouts.base')
@section('contenido')
<div class="row alert alert-primary">
    <h1>Copyright (c) 2025</h1>
</div>
@endsection
