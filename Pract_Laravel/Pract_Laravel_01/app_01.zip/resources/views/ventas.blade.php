@extends('layouts.base')
@section('contenido')
<div class="row alert alert-primary">
    <h1>Ventas</h1>
</div>
<div class="rowy">
    <p>Esta es la página de ventas</p>
</div>
<div class="row">
    <ul class="list-group">
        <li class="list-group-item">Venta 1</li>
        <li class="list-group-item">Venta 2</li>
        <li class="list-group-item">Venta 3</li>
    </ul>
</div>
<a href="{{ url('/') }}">Inicio</a>
@endsection
