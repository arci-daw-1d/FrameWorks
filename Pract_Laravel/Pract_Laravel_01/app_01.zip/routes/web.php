<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/ventas', function () {
    return view('ventas');
});

Route::get('/copyright', function () {
    return view('copyright');
});
