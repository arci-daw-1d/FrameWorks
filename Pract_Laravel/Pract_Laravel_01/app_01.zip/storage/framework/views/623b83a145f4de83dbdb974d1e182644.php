<?php $__env->startSection('contenido'); ?>
<div class="row alert alert-primary">
    <h1>Inicio</h1>
</div>
<div class="rowy">
    <p>Esta es la página de inicio</p>
</div>
<a href="<?php echo e(url('/ventas')); ?>">Ventas</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pro_rutas\app_01\resources\views/welcome.blade.php ENDPATH**/ ?>