<?php $__env->startSection('contenido'); ?>
<div class="row alert alert-primary">
    <h1>Ventas</h1>
</div>
<div class="rowy">
    <p>Esta es la página de ventas</p>
</div>
<div class="row">
    <ul class="list-group">
        <li class="list-group-item">Venta 1</li>
        <li class="list-group-item">Venta 2</li>
        <li class="list-group-item">Venta 3</li>
    </ul>
</div>
<a href="<?php echo e(url('/')); ?>">Inicio</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pro_rutas\app_01\resources\views/ventas.blade.php ENDPATH**/ ?>