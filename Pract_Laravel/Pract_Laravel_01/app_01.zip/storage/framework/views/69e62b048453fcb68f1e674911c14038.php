<?php $__env->startSection('contenido'); ?>
<div class="row alert alert-primary">
    <h1>Copyright (c) 2025</h1>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pro_rutas\app_01\resources\views/copyright.blade.php ENDPATH**/ ?>