@extends('layouts.base')
@section('contenido')
    <div class="container">
        <h1>Entrada</h1>
    </div>
@endsection
