<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/resultado', function () {
    return view('resultado');
});

Route::get('/redireccion', function () {
    return redirect('/resultado');
});

Route::post('/valor_obl/{id}', function ($id) {
   return "El valor es {$id}";
});

Route::post('/valor_opt/{id?}', function ($id=1) {
    return "El valor es {$id}";
});

Route::group(['prefix' => 'admin'], function () {
    Route::post('/valor_obl/{id}', function ($id) {
        return "El valor es {$id}";
    });

    Route::post('/valor_opt/{id?}', function ($id=1) {
        return "El valor es {$id}";
    });
});

Route::get('/nombre', function () {
    return "<p>Nombre</p>";
})->name('inicio.nombre');
