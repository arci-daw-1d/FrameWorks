<?php

namespace Tests\Models;

use App\Models\User;
use Database\Seeders\DatabaseSeeder;
use Database\Seeders\DestinosTableSeeder;
use Database\Seeders\ReservasTableSeeder;
use Database\Seeders\ValoracionesTableSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use PHPUnit\Framework\TestCase;

class UserTest extends TestCase {
//    use RefreshDatabase;

    protected function init(): void
    {
        // Run the DatabaseSeeder...
        $this->seed();

        // Run an array of specific seeders...
        $this->seed([
            DatabaseSeeder::class,
            DestinosTableSeeder::class,
            ReservasTableSeeder::class,
            ValoracionesTableSeeder::class,
        ]);
    }

    public function testCreateUser() {
//        $this->init();
        $this->assertEquals(5, User::count());

    }

}
