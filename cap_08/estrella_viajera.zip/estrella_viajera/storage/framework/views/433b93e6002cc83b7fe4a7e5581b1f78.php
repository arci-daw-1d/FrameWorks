<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>App</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

        <!-- Styles / Scripts -->
        <?php if(env('APP_ENV') == 'local'): ?>
            <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <?php else: ?>
            <?php if(file_exists(public_path('build/manifest.json'))): ?>
                <?php
                    $str = file_get_contents(public_path('build/manifest.json'));
                    $manifest = json_decode($str, true);
                ?>
                <script type="module"
                        src="/build/<?php echo e($manifest['resources/js/app.js']['file']); ?>"></script>
                <link href="/build/<?php echo e($manifest['resources/sass/app.scss']['file']); ?>"
                      rel="stylesheet" />
            <?php endif; ?>
        <?php endif; ?>
        <?php echo $__env->yieldContent('estilos'); ?>
    </head>
    <body>
    <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="container-fluid">
        <?php echo $__env->make('partials.menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>
                <?php echo $__env->yieldContent('contenido'); ?>
            </div>
        </div>
    </div>
    </body>
</html>
<?php /**PATH C:\Herd\estrella_viajera\resources\views/base.blade.php ENDPATH**/ ?>