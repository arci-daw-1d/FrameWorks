<?php $__env->startSection('contenido'); ?>
<div class="card" style="width: 36rem;">
    <div class="card-body">
        <h5 class="card-title">Hola <?php echo e(Auth::user()->name); ?></h5>
        <h6 class="card-subtitle mb-2 text-body-secondary">Introduce los nuevos datos</h6>
        <form action="<?php echo e(route('login.save_edit')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row mb-3">
                <label for="name" class="col-sm-2 col-form-label">Nombre</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="name" name="name" required value="<?php echo e(old('name')??Auth::user()->name); ?>" placeholder="Nombre">
                </div>
            </div>
            <div class="row mb-3">
                <label for="email" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <input type="email" class="form-control" id="email" name="email" required value="<?php echo e(old('email')??Auth::user()->email); ?>" placeholder="Email">
                </div>
            </div>
            <div class="row mb-3">
                <label for="passwrod" class="col-sm-2 col-form-label">Password</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
            </div>
            <div class="row mb-3">
                <label for="passwrod" class="col-sm-2 col-form-label">Password</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Grabar</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Herd\estrella_viajera\resources\views/auth/frm_edit.blade.php ENDPATH**/ ?>