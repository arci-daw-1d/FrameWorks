<?php $__env->startSection('contenido'); ?>
<div class="container">
    <form action="<?php echo e(route('list.filter')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="row mb-1">
            <div class="col-sm-4">
                <label for="nombre" class="col-sm-1 col-form-label">Nombre</label>
                <input type="text" class="form-control col-sm-3" id="nombre" name="nombre" placeholder="Nombre del destino">
            </div>
            <div class="col-sm-3">
                <label for="tipo" class="col-sm-1 col-form-label">tipo</label>
                <select class="form-select col-sm-2" id="tipo" name="tipo">
                    <option value="">Seleccione un tipo</option>
                    <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($tipo); ?>"><?php echo e($tipo); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-2">
                <button type="submit" class="btn btn-primary">Filtrar</button>
            </div>
        </div>
    </form>
</div>
<div class="container">
<?php $__currentLoopData = $destinos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mb-3" style="width: 36rem;">
        <div class="card-body">
            <h5 class="card-title alert alert-secondary"><?php echo e($item->nombre); ?></h5>
            <p class="card-text alert alert-light"><?php echo e($item->descripcion); ?></p>
            <div class="container alert-light alert">
                <p class="card-text">Tipo: <?php echo e($item->tipo); ?></p>
                <p class="card-text">Plazas: <?php echo e($item->plazas_disponibles); ?></p>
                <p class="card-text">Precio: <?php echo e($item->precio); ?>€</p>
                <p class="card-text">Duración: <?php echo e($item->duracion_viaje); ?></p>
            </div>
        </div>
        <?php if(auth()->guard()->check()): ?>
        <div class="card-footer">
            <form action="<?php echo e(route('list.reservar', $item->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <label class="col-sm-1 card-text" for="numero_pazas">Plazas</label>
                <input type="number" class="col-sm-1" name="numero_pazas" id="numero_pazas"  value="1" min="1" max="5" required>
                <button type="submit" class="btn btn-success ms-auto">Reservar</button>
            </form>
        </div>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Herd\estrella_viajera\resources\views/list/index.blade.php ENDPATH**/ ?>