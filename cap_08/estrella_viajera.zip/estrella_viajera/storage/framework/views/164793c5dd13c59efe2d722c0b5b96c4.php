<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>App</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

        <!-- Styles / Scripts -->
        <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
            <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <?php endif; ?>
    </head>
    <body>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="text-center alert alert-info">Welcome to Laravel</h1>
                <p class="text-center alert alert-secondary">This is a simple Laravel application.</p>
            </div>
        </div>
    </div>
    </body>
</html>
<?php /**PATH C:\Herd\estrella_viajera\resources\views/welcome.blade.php ENDPATH**/ ?>