<?php

namespace App\Http\Controllers;

use App\Models\Destino;
use App\Models\Reserva;
use App\Models\Valoracion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ListController extends Controller {
    public function index() {
        $destinos = Destino::all()->where('plazas_disponibles', '>', 0);
        $tipos = Destino::get_tipos();
        return view('list.index', compact('destinos', 'tipos'));
    }

    public function index_filter(Request $request) {
        $destinos = Destino::where('nombre', 'like', '%' . $request->input('nombre') . '%')
            ->where('plazas_disponibles', '>', 0);
        if (!is_null($request->input('tipo'))) { //Solo si se ha seleccionado algún tipo
            $destinos = $destinos->where('tipo', '=', $request->input('tipo'));
        }
        $destinos = $destinos->get();
        $tipos = Destino::get_tipos();
        return view('list.index', compact('destinos', 'tipos'));
    }

    public function reservar(Request $request, $id_destino) {
//        if (!Auth::check()) {
//            return redirect()->route('login.login');
//        }
        $request->validate([
            'numero_pazas' => ['required', 'int', 'min:1', 'max:5'],
        ], [
                'numero_pazas.required' => 'El número de plazas es obligatorio.',
                'numero_pazas.int' => 'El número de plazas debe ser un número entero.',
                'numero_pazas.min' => 'El número de plazas debe ser al menos 1.',
                'numero_pazas.max' => 'El número de plazas no puede ser mayor a 5.',
            ]
        );

        $destino = Destino::find($id_destino);
        if (is_null($destino)) {
            return redirect()->route('list.index')->withErrors(['error' => 'Destino no encontrado.']);
        }
        if ($destino->plazas_disponibles < $request->input('numero_pazas')) {
            return redirect()->route('list.index')->withErrors(['error' => 'No hay suficientes plazas disponibles.']);
        }
        $destino->plazas_disponibles -= $request->input('numero_pazas');
        DB::beginTransaction();
        try {
            Reserva::create([
                'fecha_reserva' => now(),
                'fecha_viaje' => now()->addDays(5),
                'user_id' => Auth::user()->id,
                'destino_id' => $id_destino,
                'num_personas' => $request->input('numero_pazas'),
                'estado' => 'CONFIRMADA',
            ]);
            $destino->save();
            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->route('list.index')->withErrors(['error' => 'Error desconocido.']);
        }
        return redirect()->route('list.index')->with('success', 'Reservado exitoso.');
    }

    public function mis_reservas(Request $request) {
//        if (!Auth::check()) {
//            return redirect()->route('login.login');
//        }
        $reservas = Reserva::all()->where('user_id', Auth::user()->id)
            ->where('estado', '=', 'CONFIRMADA');
        return view('list.mis_reservas', compact('reservas'));
    }

    public function cancelar(Request $request, $id_reserva) {
//        if (!Auth::check()) {
//            return redirect()->route('login.login');
//        }

        $reserva= Reserva::find($id_reserva);
        if (is_null($reserva)) {
            return redirect()->route('list.index')->withErrors(['error' => 'Reserva no encontrada.']);
        }
        DB::beginTransaction();
        try {
            $reserva->destino->plazas_disponibles += $reserva->num_personas;
            $reserva->destino->save();
            $reserva->delete();
            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->route('list.index')->withErrors(['error' => 'Error desconocido.']);
        }
        return redirect()->route('list.index')->with('success', 'Reservado cancelada.');
    }

    public function valorar(Request $request, $id_reserva) {
//        if (!Auth::check()) {
//            return redirect()->route('login.login');
//        }
        $reserva = Reserva::find($id_reserva);
        if (is_null($reserva)) {
            return redirect()->route('list.index')->withErrors(['error' => 'Reserva no encontrada.']);
        }
        return view('list.valorar', compact('reserva'));
    }

    public function finalizar(Request $request, $id_reserva) {
//        if (!Auth::check()){
//            return redirect()->route('login.login');
//        }
        $reserva= Reserva::find($id_reserva);
        if (is_null($reserva)) {
            return redirect()->route('list.index')->withErrors(['error' => 'Reserva no encontrada.']);
        }
        $request->validate([
            'estrellas' => ['required', 'int'],
        ], [
                'estrellas.required' => 'El número de estrellas es obligatorio.',
                'estrellas.int' => 'El número de estrellas debe ser un número entero.',
            ]
        );
        DB::beginTransaction();
        try {
            Valoracion::create([
                'reserva_id' => $id_reserva,
                'puntuacion' => $request->input('estrellas'),
                'comentario' => $request->input('comentario'),
                'user_id' => Auth::user()->id,
                'destino_id' => $reserva->destino_id,
            ]);
            $reserva->estado = 'COMPLETADA';
            $reserva->save();
            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->route('list.index')->withErrors(['error' => 'Error desconocido.']);
        }

        return $this->mis_reservas($request);
    }
}
