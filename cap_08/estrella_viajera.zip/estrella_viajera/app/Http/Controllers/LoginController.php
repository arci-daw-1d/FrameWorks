<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;
use \App\Models\User;


class LoginController extends Controller
{
    public function login():View {
        return view('auth.frm_login');
    }

    public function validate_login(Request $request):RedirectResponse {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);

        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();

            return redirect()->intended('/');
        }

        return back()->withErrors([
            'all' => 'Las credenciales no son correctas.',
        ])->onlyInput('email');

    }

    public function logout(Request $request) {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('home');
    }

    public function register():View {
        return view('auth.frm_register');
    }

    public function save_register(Request $request):RedirectResponse {
        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'unique:users,email'],
            'password' => ['required', 'confirmed', 'min:8'],
        ],[
            'email.unique' => 'El correo electrónico ya está en uso.',
            'email.email' => 'El correo electrónico no es válido.',
            'email.required' => 'El correo electrónico es obligatorio.',
            'password.confirmed' => 'Las contraseñas no coinciden.',
            'password.min' => 'La contraseña debe tener al menos 8 caracteres.',
            'password.required' => 'La contraseña es obligatoria.',
            'name.required' => 'El nombre es obligatorio.',
            'name.max' => 'El nombre no puede tener más de 255 caracteres.',
          ]
        );

        $user = new User();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = bcrypt($request->password);
        $user->fecha_registro = now();
        $user->save();

        return redirect()->route('login.login')->with('success', 'Usuario registrado correctamente.');
    }

    public function edit() {
        if (!Auth::check()) {
            return redirect()->route('login.login');
        }
        return view('auth.frm_edit');
    }

    public function save_edit(Request $request):RedirectResponse {
        if (!Auth::check()) {
            return redirect()->route('login.login')->with('error', 'Debes iniciar sesión para acceder a esta página.');
        }
        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email'],
            'password' => ['nullable', 'confirmed', 'min:8'],
        ],[
            'email.unique' => 'El correo electrónico ya está en uso.',
            'email.email' => 'El correo electrónico no es válido.',
            'email.required' => 'El correo electrónico es obligatorio.',
            'password.confirmed' => 'Las contraseñas no coinciden.',
            'password.min' => 'La contraseña debe tener al menos 8 caracteres.',
            'password.required' => 'La contraseña es obligatoria.',
            'name.required' => 'El nombre es obligatorio.',
            'name.max' => 'El nombre no puede tener más de 255 caracteres.',
          ]
        );

        $user = User::find(Auth::user()->id);
        $user->name = $request->name;
        $user->email = $request->email;
        if ($request->filled('password')) {
            $user->password = bcrypt($request->password);
        }
        $user->save();


        return redirect()->route('login.edit')->with('success', 'Usuario editado correctamente.');
    }
}
