<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Destino extends Model
{
    protected $fillable = [
        'nombre',
        'ubicacion',
        'descripcion',
        'tipo',
        'duracion_viaje',
        'precio',
        'plazas_dispionibles',
        'imagen_url',
    ];

    public function reservas(){
        return $this->hasMany(Reserva::class);
    }
    public function valoraciones(){
        return $this->hasMany(Valoracion::class);
    }
    static public function get_tipos(){
        return Destino::all()->pluck('tipo')->unique();
    }
}
