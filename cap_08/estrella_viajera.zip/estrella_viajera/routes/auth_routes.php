<?php
use Illuminate\Support\Facades\Route;
use \App\Http\Controllers\LoginController;

Route::get('/login', [LoginController::class , 'login'])->name('login.login');
Route::post('/login', [LoginController::class , 'validate_login'])->name('login.validate');
Route::get('/logout', [LoginController::class , 'logout'])->name('login.logout');
Route::get('/register', [LoginController::class , 'register'])->name('login.register');
Route::post('/register', [LoginController::class , 'save_register'])->name('login.save_register');
Route::get('/edit', [LoginController::class , 'edit'])->name('login.edit');
Route::post('/edit', [LoginController::class , 'save_edit'])->name('login.save_edit');
