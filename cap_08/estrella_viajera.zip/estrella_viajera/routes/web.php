<?php

use Illuminate\Support\Facades\Route;
use \App\Http\Controllers\ListController;

Route::get('/', function () {return view('index');})->name('home');

require __DIR__ . '/auth_routes.php';
require __DIR__ . '/list_routes.php';


