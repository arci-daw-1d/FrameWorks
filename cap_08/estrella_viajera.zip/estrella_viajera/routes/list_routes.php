<?php
use Illuminate\Support\Facades\Route;
use \App\Http\Controllers\ListController;

Route::get('/listar_reservas', [ListController::class , 'index'])->name('list.index');
Route::post('/listar_reservas', [ListController::class , 'index_filter'])->name('list.filter');
Route::post('/hacer_reserva/{id}', [ListController::class , 'reservar'])->middleware('auth')->name('list.reservar');
Route::get('/mis_reservas', [ListController::class , 'mis_reservas'])->middleware('auth')->name('list.mis_reservas');
Route::post('/cancelar_reserva/{id}', [ListController::class , 'cancelar'])->middleware('auth')->name('list.cancelar');
Route::post('/valorar_reserva/{id}', [ListController::class , 'valorar'])->middleware('auth')->name('list.valorar');
Route::post('/finalizar_reserva/{id}', [ListController::class , 'finalizar'])->middleware('auth')->name('list.finalizar');
