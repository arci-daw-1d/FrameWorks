<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>App</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

        <!-- Styles / Scripts -->
        @if (env('APP_ENV') == 'local')
            @vite(['resources/css/app.css', 'resources/js/app.js'])
        @else
            @if (file_exists(public_path('build/manifest.json')))
                @php
                    $str = file_get_contents(public_path('build/manifest.json'));
                    $manifest = json_decode($str, true);
                @endphp
                <script type="module"
                        src="/build/{{ $manifest['resources/js/app.js']['file'] }}"></script>
                <link href="/build/{{ $manifest['resources/sass/app.scss']['file'] }}"
                      rel="stylesheet" />
            @endif
        @endif
        @yield('estilos')
    </head>
    <body>
    @include('partials.header')

    <div class="container-fluid">
        @include('partials.menu')
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
                @endif
                @if (session('success'))
                <div class="alert alert-success">
                    {{ session('success') }}
                </div>
                @endif
                @yield('contenido')
            </div>
        </div>
    </div>
    </body>
</html>
