@extends('base')
@section('contenido')

<div class="container">
    <h1>Mis reservas</h1>
    @foreach ($reservas as $item)
        <div class="card mb-3" style="width: 36rem;">
            <div class="card-body">
                <h5 class="card-title alert alert-secondary">{{ $item->destino->nombre }}</h5>
                <p class="card-text alert alert-light">{{ $item->destino->descripcion }}</p>
                <div class="container alert-light alert">
                    <p class="card-text">Fecha: {{ $item->fecha_viaje }}</p>
                    <p class="card-text">Plazas: {{ $item->num_personas }}</p>
                    <p class="card-text">Precio: {{ $item->num_personas * $item->destino->precio }}€</p>
                    <p class="card-text">Duración: {{ $item->destino->duracion_viaje }}</p>
                </div>
            </div>
            @auth
            <div class="card-footer">
                <div class="btn-group"  role="group" >
                    <form action="{{ route('list.cancelar', $item->id) }}" method="post">
                        @csrf
                        <button type="submit" class="btn btn-danger me-1" title="Cancelar"><x-heroicon-o-trash/></button>
                    </form>
                    <form action="{{ route('list.valorar', $item->id) }}" method="post">
                        @csrf
                          <button type="submit" class="btn btn-success" title="Valorar"><x-heroicon-o-heart/> </button>
                    </form>
                </div>
            </div>
            @endauth
        </div>
    @endforeach
</div>
@endsection
