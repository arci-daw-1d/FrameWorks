@extends('base')
@section('contenido')
<div class="container">
    <form action="{{ route('list.filter') }}" method="post">
        @csrf
        <div class="row mb-1">
            <div class="col-sm-4">
                <label for="nombre" class="col-sm-1 col-form-label">Nombre</label>
                <input type="text" class="form-control col-sm-3" id="nombre" name="nombre" placeholder="Nombre del destino">
            </div>
            <div class="col-sm-3">
                <label for="tipo" class="col-sm-1 col-form-label">tipo</label>
                <select class="form-select col-sm-2" id="tipo" name="tipo">
                    <option value="">Seleccione un tipo</option>
                    @foreach ($tipos as $tipo)
                    <option value="{{ $tipo }}">{{ $tipo }}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-2">
                <button type="submit" class="btn btn-primary">Filtrar</button>
            </div>
        </div>
    </form>
</div>
<div class="container">
@foreach ($destinos as $item)
    <div class="card mb-3" style="width: 36rem;">
        <div class="card-body">
            <h5 class="card-title alert alert-secondary">{{ $item->nombre }}</h5>
            <p class="card-text alert alert-light">{{ $item->descripcion }}</p>
            <div class="container alert-light alert">
                <p class="card-text">Tipo: {{ $item->tipo }}</p>
                <p class="card-text">Plazas: {{ $item->plazas_disponibles }}</p>
                <p class="card-text">Precio: {{ $item->precio }}€</p>
                <p class="card-text">Duración: {{ $item->duracion_viaje }}</p>
            </div>
        </div>
        @auth
        <div class="card-footer">
            <form action="{{ route('list.reservar', $item->id) }}" method="post">
                @csrf
                <label class="col-sm-1 card-text" for="numero_pazas">Plazas</label>
                <input type="number" class="col-sm-1" name="numero_pazas" id="numero_pazas"  value="1" min="1" max="5" required>
                <button type="submit" class="btn btn-success ms-auto">Reservar</button>
            </form>
        </div>
        @endauth
    </div>
@endforeach
</div>
@endsection
