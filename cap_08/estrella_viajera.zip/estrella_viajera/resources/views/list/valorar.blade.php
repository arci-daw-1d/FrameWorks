@extends('base')
@section('estilos')
<style>
    input[type = "radio"]{
        display:none;
    }
    .clasificacion {
        direction: rtl;
        unicode-bidi: bidi-override;
    }
    label:hover, label:hover ~ label {
        color: orange;
    }
    input[type="radio"]:checked ~ label {
        color: orange;
    }
</style>
@endsection
@section('contenido')


<div class="container">
    @auth
    <h1>Cierre del viaje</h1>
    <form action="{{ route('list.finalizar', $reserva->id) }}" method="post">
        @csrf
        <div class="card mb-3" style="width: 36rem;">
        <div class="card-body">
            <h5 class="card-title alert alert-secondary">{{ $reserva->destino->nombre }}</h5>
            <div class="container alert-light alert">
                <h6 class="card-text">Fecha: {{ $reserva->fecha_viaje }} - Plazas: {{ $reserva->num_personas }}</h6>
            </div>
        </div>
        <div class="card-footer">
            <div class="row">
                <label for="comentario" class="col-form-label">Comentarios:</label>
                <textarea name="comentario" id="comentario" class="form-control" rows="3"></textarea>
            </div>
            <div class="btn-group"  role="group" >
                <p class="clasificacion me-1">
                    <button type="submit" class="btn btn-success me-1" title="Cancelar"><x-heroicon-o-check/></button>
                        <input id="radio1" type="radio" name="estrellas" value="5" readonly><!--
                        --><label for="radio1">★</label><!--
                        --><input id="radio2" type="radio" name="estrellas" value="4"><!--
                        --><label for="radio2">★</label><!--
                        --><input id="radio3" type="radio" name="estrellas" value="3"><!--
                        --><label for="radio3">★</label><!--
                        --><input id="radio4" type="radio" name="estrellas" value="2"><!--
                        --><label for="radio4">★</label><!--
                        --><input id="radio5" type="radio" name="estrellas" value="1" checked><!--
                        --><label for="radio5">★</label>
                </p>
            </div>
        </div>
    </form>
    @endauth
</div>

@endsection
