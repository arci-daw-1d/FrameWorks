@extends('base')
@section('contenido')
<div class="card" style="width: 36rem;">
    <div class="card-body">
        <h5 class="card-title">Entrada al sistema</h5>
        <h6 class="card-subtitle mb-2 text-body-secondary">Introduce los datos</h6>
        <form action="{{ route('login.validate') }}" method="post">
            @csrf
            <div class="row mb-3">
                <label for="email" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <input type="email" class="form-control" id="email" name="email" required value="{{ old('email') }}" placeholder="Email">
                </div>
            </div>
            <div class="row mb-3">
                <label for="password" class="col-sm-2 col-form-label">Password</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Login</button>
        </form>
    </div>
</div>
@endsection
