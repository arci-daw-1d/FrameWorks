<header>
    <div class="container-fluid">
        <div class="row alert alert-info">
            <div class="col-1">
                <img src="{{ Vite::asset('resources/images/logo.png') }}" alt="" class="logo" height="50">
            </div>
            <div class="col-11">
                <h1 class="text-center">Bienvenido a Estrella Viajera</h1>
            </div>
        </div>
    </div>
</header>
