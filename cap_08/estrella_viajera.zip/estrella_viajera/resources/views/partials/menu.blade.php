<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="{{ route('home') }}"><x-heroicon-o-home/></a>
                </li>
                @guest
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('list.index') }}"> Viajar...</a>
                </li>
                @endguest
                @auth
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                       aria-expanded="false">
                        Reservas
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="{{ route('list.mis_reservas') }}"><x-heroicon-o-photo/> Mis Reservas</a></li>
                        <li><a class="dropdown-item" href=" {{ route('list.index') }} "><x-heroicon-o-pencil-square/> Reservar</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="{{ route('list.mis_reservas') }}"><x-heroicon-o-heart/> Valorar</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    @if (Auth::user() && Auth::user()->isAdmin())
                        <a class="nav-link" href="#">Panel de Administración</a>
                    @else
                        <a class="nav-link disabled" aria-disabled="true">Panel de Administración</a>
                    @endif
                </li>
                @endauth
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                       aria-expanded="false">
                        <x-heroicon-o-user-group/>
                        Usuario
                    </a>
                    <ul class="dropdown-menu">
                        @auth
                        <li class="dropdown-item"><a class="nav-link" href="{{ route('login.logout') }}"><x-heroicon-o-user-minus/> Logout</a></li>
                        <li class="dropdown-item"><a class="nav-link" href="{{ route('login.edit') }}"><x-heroicon-o-user/> Mis datos</a></li>
                        @endauth
                        @guest
                        <li class="dropdown-item">
                            <a class="nav-link" href="{{ route('login.login') }}"><x-heroicon-o-user/> Login</a>
                        </li>
                        <li class="dropdown-item">
                            <a class="nav-link" href="{{ route('login.register') }}"><x-heroicon-o-user-plus/> Registrarse</a>
                        </li>
                        @endguest
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
