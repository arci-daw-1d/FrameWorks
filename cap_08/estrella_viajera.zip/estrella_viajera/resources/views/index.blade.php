@extends('base')
@section('contenido')
<div class="container-fluid">
    <h1>Página de Bienvenida</h1>
    <h2>Bienvenido a la página de inicio:  {{ Auth::user()->name?? 'Invitado' }} </h2>
    <h3>Aplicación del capítulo 8 - Módulo (optativa): Frameworks</h3>
    <p class="lead shadow-sm p-3 mb-5 bg-body-tertiary rounded">
        El proyecto es una aplicación web desarrollada en PHP con el framework Laravel, que incluye
        funcionalidades relacionadas con la gestión de usuarios, exploración de destinos espaciales, reservas
        y un panel de administración. Los usuarios pueden registrarse, iniciar sesión, modificar sus datos personales
        y explorar destinos espaciales con filtros por tipo o nombre. Además, pueden realizar reservas, consultar sus
        reservas activas, cancelarlas o finalizarlas y valorar los destinos visitados. Por otro lado, los administradores
        tienen acceso a herramientas para gestionar destinos, supervisar y cancelar reservas, y consultar estadísticas
        básicas como ingresos y valoraciones.</p>
    <p class="lead shadow-sm p-3 mb-5 bg-body-tertiary rounded">
        El código incluye controladores que manejan las operaciones principales,
        y utiliza rutas protegidas con middleware para garantizar la seguridad según el rol del usuario.
        Las vistas están diseñadas con Blade, y se emplean validaciones para garantizar la integridad de los datos.
        También se utilizan transacciones de base de datos para operaciones críticas como reservas y cancelaciones,
        asegurando consistencia en caso de errores. La estructura modular y el uso de herramientas como Composer y
        npm facilitan la gestión y escalabilidad del proyecto.
    </p>
</div>
@endsection
