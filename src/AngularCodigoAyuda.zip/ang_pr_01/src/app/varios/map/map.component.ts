
// error de la librería leaflet: "Uncaught TypeError: Cannot read properties of undefined (reading 'passive')"
import { passiveSupport } from 'passive-events-support/src/utils';

passiveSupport({
  events: ['touchstart', 'wheel'], // or any other event tyoes
});

import {AfterViewInit, Component, ElementRef, signal, ViewChild, WritableSignal} from '@angular/core';
import L, { Map, map, tileLayer } from 'leaflet';

interface locationsInterface {
  id: number
  name: string;
  latitude: number;
  longitude: number;
}

@Component({
  selector: 'app-map',
  standalone: true,
  imports: [],
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css'],
})
export class MapSimpleComponent implements AfterViewInit {

  private color = 'SlateGray';

  locations = [
    { id: 1, name: 'Azuqueca', latitude: 40.561775, longitude: -3.267617 },
    { id: 2, name: 'Guadalajara', latitude: 40.62252, longitude: -3.158269 },
    { id: 3, name: 'Chiloeches', latitude: 40.572729, longitude: -3.163011 },
    { id: 1, name: 'Azuqueca', latitude: 40.561775, longitude: -3.267617 }
  ];

  @ViewChild('map')
  mapElementRef: ElementRef = null!;
  public map: Map = null!;
  distancia: WritableSignal<string>= signal<string>("");

  private get_center(locations: any){
    let x = 0;
    let y = 0;
    let z = 0;

    for (let geoCoordinate of locations as any){  // locations should be an array of objects with latitude and longitude properties
      var latitude = geoCoordinate.latitude * Math.PI / 180;
      var longitude = geoCoordinate.longitude * Math.PI / 180;

      x += Math.cos(latitude) * Math.cos(longitude);
      y += Math.cos(latitude) * Math.sin(longitude);
      z += Math.sin(latitude);
    }

    var total = locations.length;

    x = x / total;
    y = y / total;
    z = z / total;

    var centralLongitude = Math.atan2(y, x);
    var centralSquareRoot = Math.sqrt(x * x + y * y);
    var centralLatitude = Math.atan2(z, centralSquareRoot);

    return {latitude:centralLatitude * 180 / Math.PI, longitude:centralLongitude * 180 / Math.PI};
  }

  ngAfterViewInit(): void {
      const defaultIcon = L.icon({
        iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
        shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
        iconSize: [20, 31],
        iconAnchor: [10, 31],
        popupAnchor: [1, -24],
      });

      // Set the default marker icon
      L.Marker.prototype.options.icon = defaultIcon;
      const mapContainer = this.mapElementRef.nativeElement;
      if (!mapContainer) {
        console.error('Map container not found! Make sure <div id="map"></div> exists in the DOM.');
        return;
      }

      // Initialize the map
      const center = this.get_center(this.locations);
      // this.map = map(mapContainer).setView([this.locations[0].latitude, this.locations[0].longitude], 11);
      this.map = map(mapContainer).setView([center.latitude, center.longitude], 11);

      // Add OpenStreetMap tile layer
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      }).addTo(this.map);

      // Add markers for each location
      let distancia: number = 0;
      for (let i = 0; i < this.locations.length; i++) {
        const location = this.locations[i];
        L.marker([location.latitude, location.longitude])
          .addTo(this.map)
          .bindPopup(`<b>${location.name}</b>`);
        if (i>0){ // Draw a line between the previous and current marker
          let lat_lng1: L.LatLngExpression = [this.locations[i-1].latitude, this.locations[i-1].longitude];
          let lat_lng2: L.LatLngExpression = [this.locations[i].latitude, this.locations[i].longitude];
          let _polyline = L.polyline([lat_lng1, lat_lng2], { color: this.color  });

          //add the line to the map
          _polyline.addTo(this.map);
          distancia += this.map.distance(lat_lng1, lat_lng2);
        }
      }
      this.distancia.set("distancia total:" + Math.round(distancia/ 1000) + " km");
      console.log("Ya se ha inicializado el mapa correctamente");
  }
}
