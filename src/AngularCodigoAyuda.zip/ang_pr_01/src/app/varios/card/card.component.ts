import {Component, EventEmitter, Input, Output, output} from '@angular/core';

@Component({
  selector: 'app-card',
  imports: [],
  templateUrl: './card.component.html',
  styleUrl: './card.component.css'
})
export class CardComponent {
  @Input() title: string = '';
  @Input() description: string = '';
  @Input() imageUrl: string = '';
  @Input() buttonText: string = 'Learn More';
  @Output() buttonClick = new EventEmitter<string>();

  onButtonClick() {
    this.buttonClick.emit(this.title);
  }
}
