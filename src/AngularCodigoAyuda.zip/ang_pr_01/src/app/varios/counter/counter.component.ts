import { Component } from '@angular/core';
import {DecimalPipe} from '@angular/common';

@Component({
  selector: 'app-counter',
  imports: [
    DecimalPipe
  ],
  templateUrl: './counter.component.html',
  styleUrl: './counter.component.css'
})
export class CounterComponent {
  counter: number = 0;
  history: string = "";
  negative: boolean = false;

  increment() {
    this.history += " "  + (this.counter);
    this.counter++;
    if (this.counter >= 0) this.negative = false;
  }
  decrement() {
    this.history+=" "  + (this.counter);
    this.counter--;
    if (this.counter < 0) this.negative = true;
  }
  reset() {
    this.negative = false;
    this.counter = 0;
    this.history = "";
  }
}
