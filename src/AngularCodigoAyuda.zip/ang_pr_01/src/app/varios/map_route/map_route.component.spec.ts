import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MapRouteComponent } from './map_route.component';

describe('MapComponent', () => {
  let component: MapRouteComponent;
  let fixture: ComponentFixture<MapRouteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MapRouteComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MapRouteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
