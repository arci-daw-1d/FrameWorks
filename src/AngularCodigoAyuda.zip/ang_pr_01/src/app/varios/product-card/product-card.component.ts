import { Component, OnInit } from '@angular/core';
import {CurrencyPipe} from '@angular/common';

@Component({
  selector: 'app-product-card',
  templateUrl: './product-card.component.html',
  imports: [
    CurrencyPipe
  ],
  styleUrl: './product-card.component.css'
})
export class ProductCardComponent implements OnInit{
  protected productName: string = 'Product Name';
  protected productPrice: number = 99.99;
  protected productDescription: string = 'This is a great product that you will love!';
  protected productImage: string = 'http://www.home.unix-ag.org/simon/penguin/penguin.svg';

  constructor() {}

  ngOnInit(): void {
    // Initialization logic can go here
  }

  addToCart(): void {
    alert(`${this.productName} has been added to the cart.`);
  }

  viewDetails(): void {
    console.log(`Viewing details for ${this.productName}`);
  }
}
