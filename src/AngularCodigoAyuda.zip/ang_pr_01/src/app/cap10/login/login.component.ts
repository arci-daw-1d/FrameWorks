import {Component, ElementRef, ViewChild} from '@angular/core';
import {FormsModule} from '@angular/forms';

@Component({
  selector: 'app-login',
  imports: [
    FormsModule
  ],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  password: string = '';
  username: string = '';
  @ViewChild('frmLogin', { static: true }) frmLogin!: ElementRef;

  login() {
    alert(`Username: ${this.username}, Password: ${this.password}`);
  }

  reset() {
    this.frmLogin.nativeElement.reset();
  }

  onChange($event: any) {
    alert("ngEvent: " + $event);
  }
}
