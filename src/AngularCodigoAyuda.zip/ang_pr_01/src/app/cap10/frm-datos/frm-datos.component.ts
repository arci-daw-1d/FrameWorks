import { Component } from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {Observable, Subscription} from 'rxjs';

@Component({
  selector: 'app-frm-datos',
  imports: [
    ReactiveFormsModule
  ],
  templateUrl: './frm-datos.component.html',
  styleUrl: './frm-datos.component.css'
})
export class FrmDatosComponent {
  formulario= new FormGroup({
    nombre: new FormControl('Nombre', {nonNullable: true, validators: Validators.required} ),
    apellido: new FormControl('Apellido', {nonNullable: true, validators: Validators.required} ),
    email: new FormControl('email@email.com', {nonNullable: true, validators: [Validators.required, Validators.email] } ),
  });
  private observable_suscripcion: Subscription = new Subscription();


  onSubmit() {
    alert(this.formulario.controls.nombre.value);
  }

  onEnviar() {
    alert("On enviar");
  }

  onSuscribir() {
    this.observable_suscripcion = this.formulario.controls.apellido.valueChanges.subscribe(
      (apellido) => {
        alert(apellido);
      }
    );
  }

  onQuitar() {
    this.observable_suscripcion.unsubscribe();
  }
}
