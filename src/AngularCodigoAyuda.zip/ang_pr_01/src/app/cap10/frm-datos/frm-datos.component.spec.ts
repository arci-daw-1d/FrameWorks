import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FrmDatosComponent } from './frm-datos.component';

describe('FrmDatosComponent', () => {
  let component: FrmDatosComponent;
  let fixture: ComponentFixture<FrmDatosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FrmDatosComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FrmDatosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
