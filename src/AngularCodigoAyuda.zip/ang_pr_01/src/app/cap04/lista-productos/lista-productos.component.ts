import { Component } from '@angular/core';
import { Producto } from '../producto';
import { DetallesProductoComponent } from '../detalles-producto/detalles-producto.component';
import {SortPipe} from '../sort.pipe';

@Component({
  selector: 'app-lista-productos',
  imports: [DetallesProductoComponent, SortPipe],
  templateUrl: './lista-productos.component.html',
  styleUrl: './lista-productos.component.css'
})
export class ListaProductosComponent {
  title: string = 'Lista de Productos';
  productos: Producto[] = [
    { id: 1, nombre: 'Producto 11', precio: 10.99, categorias: {1: 'Cat 1' , 2:'Cat 2'} },
    { id: 2, nombre: 'Producto 2', precio: 20.99, categorias: {1: 'Cat 1' , 2:'Cat 2'} },
    { id: 3, nombre: 'Producto 13', precio: 30.99, categorias: {2: 'Cat 2' , 3:'Cat 3'} },
    { id: 4, nombre: 'Producto 4', precio: 40.99, categorias: {2: 'Cat 3' , 3:'Cat 3'} },
    { id: 5, nombre: 'Producto 5', precio: 50.99, categorias: {2:'Cat 2'} }
  ];

  productoSeleccionado: Producto | null = null;

  seleccionarProducto(producto: Producto): void {
    if (this.productoSeleccionado !== producto && this.productoSeleccionado !== null) {
      this.productoSeleccionado.seleccionado = false;
    }
    this.productoSeleccionado = producto;
    this.productoSeleccionado.seleccionado = true;
  }

  onClicBoton(e:string): void {
    alert("El hijo dice:" + e);
  }
}
