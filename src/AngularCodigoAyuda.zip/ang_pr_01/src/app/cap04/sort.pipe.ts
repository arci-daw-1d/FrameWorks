import { Pipe, PipeTransform } from '@angular/core';
import {Producto} from './producto';

@Pipe({
  name: 'sort'
})
export class SortPipe implements PipeTransform {
  transform(value: Producto[], args: unknown = 'nombre'): Producto[] {
    if (!value || !Array.isArray(value)) {
      return value;
    }
    return value.sort((a, b) => {
      if (a.nombre < b.nombre) {
        return -1;
      }
      if (a.nombre > b.nombre) {
        return 1;
      }
      return 0;
    });
  }
}
