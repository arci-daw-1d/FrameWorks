import { Routes } from '@angular/router';
import {Ruta01Component} from './cap09/ruta-01/ruta-01.component';
import {Ruta02Component} from './cap09/ruta-02/ruta-02.component';
import {Hijo1Component} from './cap09/ruta-02/hijo-1/hijo-1.component';
import {Hijo2Component} from './cap09/ruta-02/hijo-2/hijo-2.component';
import {Ruta03Component} from './cap09/ruta-03/ruta-03.component';
import {DetallesProductoComponent} from './cap09/ruta-03/detalles-producto/detalles-producto.component';
import {authGuard} from './cap09/auth.guard';


export const routes: Routes = [
  {path: 'ruta_1', component: Ruta01Component },
  {path: 'ruta_2', component: Ruta02Component },
  {path: 'ruta_2/hijo_1', component: Hijo1Component },
  {path: 'ruta_2/hijo_2', component: Hijo2Component },
  // {path: 'ruta_3/:id', component: DetallesProductoComponent },
  {
    path: 'ruta_3',
    component: Ruta03Component,
    children: [
      {path: ':id', component: DetallesProductoComponent },
    ]
  },
  {path: 'ruta_4', component: Ruta02Component, canActivate: [authGuard] },
  // {path: 'ruta_5', loadChildren:() => import('./routes/ruta-05.routes') },
  {path: 'ruta_5', loadComponent:() => import('./cap09/ruta-03/ruta-03.component').then(c => c.Ruta03Component) },

  {path: '', redirectTo: '/ruta_3', pathMatch: 'full' },
  {path: '**', redirectTo: '/ruta_2'},
];
