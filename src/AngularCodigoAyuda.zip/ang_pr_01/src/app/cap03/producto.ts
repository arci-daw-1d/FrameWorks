export interface Producto {
  id: number,
  nombre: string,
  precio: number,
  seleccionado?: boolean
}
