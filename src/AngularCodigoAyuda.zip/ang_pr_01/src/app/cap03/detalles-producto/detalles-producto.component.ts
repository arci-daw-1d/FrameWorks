import {Component, Input, input, output, OnInit} from '@angular/core';
import { Producto } from '../producto';


@Component({
  selector: 'app-detalles-producto',
  imports: [],
  templateUrl: './detalles-producto.component.html',
  styleUrl: './detalles-producto.component.css'
})
export class DetallesProductoComponent implements OnInit{
  // producto = input.required<Producto>;
  @Input({required: true}) producto: Producto|null = null;

  clic_buton = output<string>();
  clicBoton(): void {
    this.clic_buton.emit("Emitido por "+ this.producto?.id);
  }

  ngOnInit(): void {
    if (this.producto) {
      console.log('Detalles del producto:', this.producto);
    } else {
      console.log('No se ha proporcionado un producto.');
    }
  }
}
