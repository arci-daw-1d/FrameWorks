import {Component, output} from '@angular/core';
import {Persona} from './persona';
import {FormsModule} from '@angular/forms';

@Component({
  selector: 'app-frm-login',
  imports: [
    FormsModule
  ],
  templateUrl: './frm-login.component.html',
  styleUrl: './frm-login.component.css'
})
export class FrmLoginComponent {
  // Propiedades
  persona: Persona = {email: '', password: ''};

  on_enviar = output<Persona>();

  clicEnviar() {
    this.on_enviar.emit(this.persona);
  }

}
