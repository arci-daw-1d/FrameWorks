export interface Persona {
  email: string;
  password: string;
}
