import { Ruta03Component } from '../cap09/ruta-03/ruta-03.component';
export default [{path: '', component: Ruta03Component}];
