import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Ruta03Component } from './ruta-03.component';

describe('Ruta02Component', () => {
  let component: Ruta03Component;
  let fixture: ComponentFixture<Ruta03Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Ruta03Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Ruta03Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
