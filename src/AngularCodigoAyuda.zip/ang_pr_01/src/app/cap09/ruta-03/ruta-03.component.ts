import { Component } from '@angular/core';
import {RouterLink, RouterOutlet} from '@angular/router';
import {ListaProductosComponent} from '../../cap09/ruta-03/lista-productos/lista-productos.component';

@Component({
  selector: 'app-ruta-03',
  imports: [
    RouterLink,
    RouterOutlet,
    ListaProductosComponent
  ],
  templateUrl: './ruta-03.component.html',
  styleUrl: './ruta-03.component.css'
})
export class Ruta03Component {

}
