import {Component, Input, input, output, OnInit} from '@angular/core';
import { Producto } from '../producto';
import {ActivatedRoute, Router} from '@angular/router';
import {ListaProductosComponent} from '../lista-productos/lista-productos.component';
import {Observable, of, switchMap} from 'rxjs';


@Component({
  selector: 'app-detalles-producto',
  imports: [],
  templateUrl: './detalles-producto.component.html',
  styleUrl: './detalles-producto.component.css'
})
export class DetallesProductoComponent implements OnInit {
  producto$: Observable<Producto>|undefined;
  producto: Producto | null = null;

  constructor(private lista: ListaProductosComponent, private route: ActivatedRoute, private router: Router) {}

  ngOnInit(): void {
    this.producto$ = this.route.paramMap.pipe(
      switchMap(params => {
        const producto = this.lista.findProducto(Number(params.get('id')))||{} as Producto;
        return of(producto);
      })
    );
    this.producto$?.subscribe(params => {
      this.producto = params;
    });
  }
}
