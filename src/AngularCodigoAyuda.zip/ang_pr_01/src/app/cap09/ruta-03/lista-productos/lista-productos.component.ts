import { Component } from '@angular/core';
import { Producto } from '../producto';
import { DetallesProductoComponent } from '../detalles-producto/detalles-producto.component';
import {RouterLink, RouterOutlet} from '@angular/router';
import {Observable} from 'rxjs';

@Component({
  selector: 'app-lista-productos',
  imports: [DetallesProductoComponent, RouterLink, RouterOutlet],
  templateUrl: './lista-productos.component.html',
  styleUrl: './lista-productos.component.css'
})
export class ListaProductosComponent {
  title: string = 'Lista de Productos';
  productos: Producto[] = [
    { id: 1, nombre: 'Producto 1', precio: 10.99 },
    { id: 2, nombre: 'Producto 2', precio: 20.99 },
    { id: 3, nombre: 'Producto 3', precio: 30.99 },
    { id: 4, nombre: 'Producto 4', precio: 40.99 },
    { id: 5, nombre: 'Producto 5', precio: 50.99 }
  ];

  productoSeleccionado: Producto | null = null;

  seleccionarProducto(producto: Producto): void {
    if (this.productoSeleccionado !== producto && this.productoSeleccionado !== null) {
      this.productoSeleccionado.seleccionado = false;
    }
    this.productoSeleccionado = producto;
    this.productoSeleccionado.seleccionado = true;
  }

  findProducto(id: number): Producto|undefined {
    return this.productos.find(p => p.id === id) ;
  }
}
