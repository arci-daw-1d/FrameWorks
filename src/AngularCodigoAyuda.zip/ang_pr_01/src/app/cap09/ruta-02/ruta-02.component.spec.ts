import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Ruta02Component } from './ruta-02.component';

describe('Ruta02Component', () => {
  let component: Ruta02Component;
  let fixture: ComponentFixture<Ruta02Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Ruta02Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Ruta02Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
