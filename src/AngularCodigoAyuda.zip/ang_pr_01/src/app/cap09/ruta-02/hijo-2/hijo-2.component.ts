import { Component } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-hijo-2',
  imports: [],
  templateUrl: './hijo-2.component.html',
  styleUrl: './hijo-2.component.css'
})
export class Hijo2Component {
  constructor(private router: Router) {}
  onClick() {
    this.router.navigate(['/ruta_2/hijo_1']);
  }
}
