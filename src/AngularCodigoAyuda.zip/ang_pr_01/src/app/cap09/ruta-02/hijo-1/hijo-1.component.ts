import { Component } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-hijo-1',
  imports: [],
  templateUrl: './hijo-1.component.html',
  styleUrl: './hijo-1.component.css'
})
export class Hijo1Component {
  constructor(private router: Router) {}
  onClick() {
    this.router.navigate(['/ruta_2/hijo_2']);
  }
}
