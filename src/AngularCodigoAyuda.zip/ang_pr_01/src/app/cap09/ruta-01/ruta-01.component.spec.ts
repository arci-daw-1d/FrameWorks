import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Ruta01Component } from './ruta-01.component';

describe('Ruta01Component', () => {
  let component: Ruta01Component;
  let fixture: ComponentFixture<Ruta01Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Ruta01Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Ruta01Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
