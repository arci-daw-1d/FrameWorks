import { Component } from '@angular/core';

@Component({
  selector: 'app-ruta-01',
  imports: [],
  templateUrl: './ruta-01.component.html',
  styleUrl: './ruta-01.component.css'
})
export class Ruta01Component {

}
