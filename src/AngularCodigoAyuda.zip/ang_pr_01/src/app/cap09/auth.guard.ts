import {CanActivateFn, Router} from '@angular/router';
import { inject } from '@angular/core';


export const authGuard: CanActivateFn = (route, state) => {
  // modificar esto con un servicio de autorización
  const router = inject(Router);
  // return true;
  return router.parseUrl('/ruta_2');  //esta la forma más recomendada para la redirección
};
