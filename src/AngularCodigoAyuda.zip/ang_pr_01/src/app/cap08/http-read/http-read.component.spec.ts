import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpReadComponent } from './http-read.component';

describe('HttpReadComponent', () => {
  let component: HttpReadComponent;
  let fixture: ComponentFixture<HttpReadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpReadComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HttpReadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
