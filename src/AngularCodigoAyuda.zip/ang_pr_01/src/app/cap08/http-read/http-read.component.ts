import {Component, OnDestroy} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable, Subscription, tap} from 'rxjs';

@Component({
  selector: 'app-http-read',
  imports: [],
  templateUrl: './http-read.component.html',
  styleUrl: './http-read.component.css'
})
export class HttpReadComponent implements OnDestroy{
  URL = 'http://localhost/public/graphql';
  private observado: Subscription;
  title: string = '';

  constructor(private http: HttpClient) {
    this.observado =this.getData().subscribe(params  => {
      this.setTitle(JSON.stringify(params));
    });
  }

  getData(): Observable<any> {
    const headers= new HttpHeaders().set('Authorization', 'Bearer 16|2P9g7CuzsfRCptZ3YiL9RqCpJJ0voIQA4OT5dTdXc8212c93');
    // const post_params = { query : " query { login(email:\"a@a\", password:\"a\")}" };
    const post_params = { query : " query { logout }" };
    return this.http.post(this.URL, post_params, {headers: headers});
  }

  setTitle(title: string){
    this.title = title;
  }

  ngOnDestroy() {
    if (this.observado) {
      this.observado.unsubscribe();
    }
  }
}
