import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpRead_clickComponent } from './http-read_click.component';

describe('HttpReadComponent', () => {
  let component: HttpRead_clickComponent;
  let fixture: ComponentFixture<HttpRead_clickComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpRead_clickComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HttpRead_clickComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
