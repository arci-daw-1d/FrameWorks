import {Component, inject, OnDestroy} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable, Subscription, tap} from 'rxjs';

@Component({
  selector: 'app-http-read_click',
  imports: [],
  templateUrl: './http-read_click.component.html',
  styleUrl: './http-read_click.component.css'
})
export class HttpRead_clickComponent{
  URL = 'http://localhost/public/graphql';
  private observado: Subscription = new Subscription();
  title: string = '';
  private http= inject(HttpClient);

  // constructor(private http: HttpClient) {  }

  getData(): Observable<any> {
    const headers= new HttpHeaders().set('Authorization', 'Bearer 17|eaYs9PGKUw4bOj5hxnPYvLMC9j1RJM4AVO5WSinic1b629e5');
    // const post_params = { query : " query { login(email:\"a@a\", password:\"a\")}" };
    const post_params = { query : " query { logout }" };
    return this.http.post(this.URL, post_params, {headers: headers});
  }

  setTitle(title: string){
    this.title = title;
  }

  onClick(){
    this.observado =this.getData().subscribe(params  => {
      this.setTitle(JSON.stringify(params));
      if (this.observado) {
        this.observado.unsubscribe();
      }
    });
  }
}
