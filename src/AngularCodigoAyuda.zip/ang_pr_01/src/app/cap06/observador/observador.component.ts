import {Component, OnDestroy} from '@angular/core';
import {Observable, Subscription} from 'rxjs';

@Component({
  selector: 'app-observador',
  imports: [],
  templateUrl: './observador.component.html',
  styleUrl: './observador.component.css'
})
export class ObservadorComponent implements OnDestroy{
  title:string = 'Hello';
  private observado: Subscription;

  title$ = new Observable(
    observador => {
      let i = 0;
      setInterval(() => {
          i++;
          observador.next("Hello : " + String(i));
        },
        2000);
    }
  );


  constructor(){
    this.observado = this.title$.subscribe(params  => {
      this.setTitle(String(params));
    });
  };

  setTitle(title: string){
    this.title = title;
  }

  ngOnDestroy(): void {
    this.observado.unsubscribe();
  }
}
