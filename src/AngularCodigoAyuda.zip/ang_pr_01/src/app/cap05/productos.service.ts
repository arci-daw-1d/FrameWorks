import { Injectable } from '@angular/core';
import {Producto} from './producto';

@Injectable({
  providedIn: 'root'
})
export class ProductosService {
  constructor() { }
  getProductos(): Producto[] {
    return   [
      { id: 1, nombre: 'Producto Gen 11', precio: 10.99, categorias: {1: 'Cat 1' , 2:'Cat 2'} },
      { id: 2, nombre: 'Producto Gen 2', precio: 20.99, categorias: {1: 'Cat 1' , 2:'Cat 2'} },
      { id: 3, nombre: 'Producto Gen 13', precio: 30.99, categorias: {2: 'Cat 2' , 3:'Cat 3'} },
      { id: 4, nombre: 'Producto Gen 4', precio: 40.99, categorias: {2: 'Cat 3' , 3:'Cat 3'} },
      { id: 5, nombre: 'Producto Gen 5', precio: 50.99, categorias: {2:'Cat 2'} }
    ];
  }
}
