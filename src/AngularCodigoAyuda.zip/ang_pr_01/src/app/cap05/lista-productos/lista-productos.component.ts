import {Component, inject, OnInit} from '@angular/core';
import { Producto } from '../producto';
import { DetallesProductoComponent } from '../detalles-producto/detalles-producto.component';
import {SortPipe} from '../sort.pipe';
import {ProductosService} from '../productos.service';

@Component({
  selector: 'app-lista-productos',
  imports: [DetallesProductoComponent, SortPipe],
  templateUrl: './lista-productos.component.html',
  styleUrl: './lista-productos.component.css'
})
export class ListaProductosComponent implements OnInit{
  title: string = 'Lista de Productos';
  productos: Producto[] = [];
  private servicioProductos= inject(ProductosService);
  // constructor(private servicioProductos: ProductosService ) {}

  ngOnInit(): void {
    this.productos = this.servicioProductos.getProductos();
  }

  productoSeleccionado: Producto | null = null;

  seleccionarProducto(producto: Producto): void {
    if (this.productoSeleccionado !== producto && this.productoSeleccionado !== null) {
      this.productoSeleccionado.seleccionado = false;
    }
    this.productoSeleccionado = producto;
    this.productoSeleccionado.seleccionado = true;
  }

  onClicBoton(e:string): void {
    alert("El hijo dice:" + e);
  }
}
