import {RouterLink, RouterLinkActive, RouterOutlet} from '@angular/router';
import {LoginComponent} from './cap10/login/login.component';
import {FrmDatosComponent} from './cap10/frm-datos/frm-datos.component';
import {MapSimpleComponent} from './varios/map/map.component';
import { AfterViewInit, Component, ElementRef, ViewChild } from '@angular/core';
import {MapRouteComponent} from './varios/map_route/map_route.component';

@Component({
  selector: 'app-root',
  imports: [
    MapRouteComponent
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent { //implements AfterViewInit
  title = 'ang_pr_01';
}

