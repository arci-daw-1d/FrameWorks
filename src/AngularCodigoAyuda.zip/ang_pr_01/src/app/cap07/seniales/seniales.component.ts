import {Component, computed, OnDestroy, Signal, signal, WritableSignal} from '@angular/core';
import {Observable, Subscription} from 'rxjs';

@Component({
  selector: 'app-seniales',
  imports: [],
  templateUrl: './seniales.component.html',
  styleUrl: './seniales.component.css'
})
export class SenialesComponent implements OnDestroy{
  private observado: Subscription;
  title: Signal<string> = signal('');

  fecha$ = new Observable(
    observador => {
      let i = 0;
      setInterval(() => {
          i++;
          observador.next("Hello : " + String(i));
        },
        2000);
    }
  );
  constructor(){
    this.observado =this.fecha$.subscribe(params  => {
      this.setTitle(String(params));
    });
    this.title = computed( () =>{ return "Fecha: " + this.currentDate() }  );

  };

  ngOnDestroy(): void {
    this.observado.unsubscribe();
  }

  currentDate: WritableSignal<Date> = signal(new Date());

  setTitle(title: string){
    this.currentDate.set(new Date());
    // this.currentDate.update( fecha_actual => new Date(fecha_actual.getFullYear(), fecha_actual.getMonth(), fecha_actual.getDate(), 0, 0));
  }




}
