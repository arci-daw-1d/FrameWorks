<?php

namespace CSJP\varios;

class Log {
    public string $val="";
}
