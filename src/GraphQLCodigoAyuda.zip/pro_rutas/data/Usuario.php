<?php
declare(strict_types=1);
namespace CSJP;

use CSJP\varios\Log;

class Usuario {
    public string $nombre="";
    public Log $log;

    public function __construct(string $nombre){
        $this->nombre = $nombre;
    }

    public function __toString():string {
        return $this->nombre . " - " . $this->log->val;
    }
}
