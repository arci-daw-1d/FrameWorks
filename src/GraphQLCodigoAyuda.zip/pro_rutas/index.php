<?php
declare(strict_types=1);

require_once __DIR__ . '/./vendor/autoload.php';

use CSJP\Usuario;
use CSJP\Varios\Log;

$usuario = new Usuario("Carlos");
$usuario->log = new Log();
$usuario->log->val = "Valores de log";

echo $usuario;

