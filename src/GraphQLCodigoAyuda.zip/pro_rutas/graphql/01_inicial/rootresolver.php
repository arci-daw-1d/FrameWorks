<?php

$root_fileds_Resolver = [
    'hello' => static fn ($rootValue, array $args): string => 'Hola Mundo!',
    'echo' => static fn ($rootValue, array $args): string => 'Hello ' . $args['name'] . '!',
    'add' => static fn ($rootValue, array $args): int => (int)$args['id'] + 5,
];