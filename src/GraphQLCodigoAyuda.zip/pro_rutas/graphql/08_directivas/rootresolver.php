<?php

$root_fileds_Resolver = [
    'human' => function ($rootValue, array $args, $conf, $info) {
            return ["name" => "my name {$args['id']}", "height" => 5.66];
        },
    'echo' => static fn($rootValue, array $args): string => "echo"
];


$fileds_Resolver= function($objectValue, $args, $context, $info)
{
    $fieldName = $info->fieldName;
    $directives = $info->fieldDefinition->astNode->directives??null;
    $property = null;

    // resolución por defecto, si es array o objeto, y es el nombre de propiedad o campo se devuelve
    if (is_array($objectValue) || $objectValue instanceof ArrayAccess) {
        if (isset($objectValue[$fieldName])) {
            $property = $objectValue[$fieldName];
        }
    } elseif (is_object($objectValue)) {
        if (isset($objectValue->{$fieldName})) {
            $property = $objectValue->{$fieldName};
        }
    }
    // Gestión de las directivas
    if (!$property instanceof Closure) {  //  si no es una funcion
        foreach  ($directives as $directive){  // recorremos todas las directivas
            if ($directive->name->value == 'upper') {
                $property = strtoupper($property);
            }
            if ($directive->name->value == 'add_txt') {
                $property = $property . "_txt";
            }
            if ($directive->name->value == 'no_run') {
                throw new GraphQL\Error\Error("no_run directive");
            }
        }
    }
    else if ($property instanceof Closure){  // si es una función hay que hacer otra cosa
        foreach  ($directives as $directive) {
            if ($directive->name->value == 'no_run') {
                throw new GraphQL\Error\Error("no_run directive");
            }
        }
        $property = $property($objectValue, $args, $context, $info);
    }
    return $property;
};