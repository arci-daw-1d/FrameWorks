<?php

use GraphQL\Type\Definition\Type;
use GraphQL\Type\Definition\ObjectType;
use GraphQL\Type\Definition\InterfaceType;
use GraphQL\Type\Schema;

class Author extends ObjectType
{
    public function __construct()
    {
        parent::__construct([
            'fields' => [
                'firstName' => Type::nonNull(Type::string()),
                'lastName' => Type::nonNull(Type::string()),
                'books' => Type::listOf(Type::string())
            ]
        ]);
    }
}

class Publisher extends ObjectType
{
    public function __construct()
    {
        parent::__construct([
            'fields' => [
                'name' => Type::nonNull(Type::string())
            ]
        ]);
    }
}


class LibraryItem extends InterfaceType{
    public function __construct()
    {
        parent::__construct([
            'fields' => [
                'id' => Type::nonNull(Type::id()),
                'title' => Type::nonNull(Type::string())
            ],
            'resolveType' => function ($value) : ObjectType {
                if (isset($value['authors'])) {
                    return MyTypes::book();
                }
                if (isset($value['publisher'])) {
                    return MyTypes::boardGame();
                }
                throw new Exception("Unknown type");
            }
        ]);
    }
}


class Book extends ObjectType
{
    public function __construct()
    {
        parent::__construct([
            'interfaces' => [MyTypes::LibraryItem()],
            'fields' => [
                'id' => Type::nonNull(Type::id()),
                'title' => Type::nonNull(Type::string()),
                'authors' => Type::listOf(MyTypes::autor())
            ]
        ]);
    }
}

class BoardGame extends ObjectType
{
    public function __construct()
    {
        parent::__construct([
            'fields' => [
                'id' => Type::nonNull(Type::id()),
                'title' => Type::nonNull(Type::string()),
                'publisher' => MyTypes::publisher()
            ],
            'interfaces' => [MyTypes::LibraryItem()],
        ]);
    }
}

class MyTypes
{
    /*
     * Creamos esta clase porque el tipo debe ser úinico en el esquema y usamos el patrón singleton
     * */
    private static LibraryItem $interfaceLibraryItem;
    private static Book $bookObjectType;
    private static BoardGame $boardGameObjectType;
    private static Author $autorObjectType;
    private static Publisher $publisherObjectType;

    public static function libraryItem(): LibraryItem
    {
        return self::$interfaceLibraryItem ??= new LibraryItem();
    }
    public static function book(): Book{
        return self::$bookObjectType ??= new Book();
    }
    public static function boardGame(): BoardGame{
        return self::$boardGameObjectType ??= new BoardGame();
    }
    public static function autor(): Author{
        return self::$autorObjectType ??= new Author();
    }

    public static function publisher(): Publisher{
        return self::$publisherObjectType ??= new Publisher();
    }
}


$schema = new Schema([
    'query' => new ObjectType([
        'name' => 'Query',
        'fields' => [
            'libraryItems' => [
                'type' => Type::listOf(MyTypes::LibraryItem()),
                'resolve' => function () {
                    $books = [
                        [
                            'id' => '1',
                            'title' => 'Book 1',
                            'authors' => [
                                ['firstName' => 'Author 1', 'lastName' => 'One', 'books' => []]
                            ]
                        ],
                        [
                            'id' => '2',
                            'title' => 'Book 2',
                            'authors' => [
                                ['firstName' => 'Author 2', 'lastName' => 'Two', 'books' => []]
                            ]
                        ]
                    ];

                    $boardGames = [
                        [
                            'id' => '1',
                            'title' => 'Board Game 1',
                            'publisher' => ['name' => 'Publisher 1']
                        ],
                        [
                            'id' => '2',
                            'title' => 'Board Game 2',
                            'publisher' => ['name' => 'Publisher 2']
                        ]
                    ];
                    return (array_merge($books, $boardGames)); //, array_merge $boardGames
                }
            ]
        ]
    ]),
    'types' => [MyTypes::book(), MyTypes::boardGame()],
]);

/*
query {
    libraryItems {
        __typename
        id
        title
        ... on BoardGame {
            publisher {
                name
            }
        }
        ... on Book {
            authors {
                firstName
                lastName
                books
            }
        }
    }
}
*/
