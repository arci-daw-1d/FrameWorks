<?php
declare(strict_types=1);

require_once __DIR__ . '/../vendor/autoload.php';

// https://webonyx.github.io/graphql-php
use GraphQL\Server\StandardServer;
global $schema;

include 'schema.php';


$server = new StandardServer([
    'schema' => $schema,
]);
try{
    $server->handleRequest();
}
catch (Exception $e){
    echo json_encode(['error' => $e->getMessage()]);
}


