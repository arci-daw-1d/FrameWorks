<?php

$root_fileds_Resolver = [
    'echo' => function ($rootValue, array $args) {
            if ($args['name'] < 0)
                return 'NEWHOPE';
            if ($args['name'] > 0)
                return 'EMPIRE';
            return 'JEDI';
        },
];