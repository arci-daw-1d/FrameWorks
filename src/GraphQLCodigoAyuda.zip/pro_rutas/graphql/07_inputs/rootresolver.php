<?php

$root_fileds_Resolver = [
    'echo' => function ($rootValue, array $args) {
            if ($args['name']['firstName'] === "Luke")
                return 'NEWHOPE';
            if ($args['name']['firstName'] === "Darth")
                return 'EMPIRE';
            return 'JEDI';
        },
];