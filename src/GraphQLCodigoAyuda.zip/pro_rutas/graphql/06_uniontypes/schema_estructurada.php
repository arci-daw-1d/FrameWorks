<?php

use GraphQL\Type\Definition\Type;
use GraphQL\Type\Definition\ObjectType;
use GraphQL\Type\Definition\UnionType;
use GraphQL\Type\Schema;

$authorType = new ObjectType([
    'name' => 'Author',
    'fields' => [
        'firstName' => Type::nonNull(Type::string()),
        'lastName' => Type::nonNull(Type::string()),
        'books' => Type::listOf(Type::string())
    ]
]);

$publisherType = new ObjectType([
    'name' => 'Publisher',
    'fields' => [
        'name' => Type::nonNull(Type::string())
    ]
]);

$bookType = new ObjectType([
    'name' => 'Book',
    'fields' => [
        'id' => Type::nonNull(Type::id()),
        'title' => Type::nonNull(Type::string()),
        'authors' => Type::listOf($authorType)
    ]
]);

$boardGameType = new ObjectType([
    'name' => 'BoardGame',
    'fields' => [
        'id' => Type::nonNull(Type::id()),
        'title' => Type::nonNull(Type::string()),
        'publisher' => $publisherType
    ]
]);

$searchResultType = new UnionType([
    'name' => 'SearchResult',
    'types' => [
        $bookType,
        $boardGameType
    ],
    'resolveType' => function ($value) use ($bookType, $boardGameType): ObjectType {
        if (isset($value['authors'])) {
            return $bookType;
        }
        if (isset($value['publisher'])) {
            return $boardGameType;
        }
        throw new Exception("Unknown type");
    },
]);

$schema = new Schema([
    'query' => new ObjectType([
        'name' => 'Query',
        'fields' => [
            'libraryItems' => [
                'type' => Type::listOf($searchResultType),
                'resolve' => function () {
                    $books = [
                        [
                            'id' => '1',
                            'title' => 'Book 1',
                            'authors' => [
                                ['firstName' => 'Author', 'lastName' => 'One', 'books' => []]
                            ]
                        ],
                        [
                            'id' => '2',
                            'title' => 'Book 2',
                            'authors' => [
                                ['firstName' => 'Author', 'lastName' => 'Two', 'books' => []]
                            ]
                        ]
                    ];

                    $boardGames = [
                        [
                            'id' => '1',
                            'title' => 'Board Game 1',
                            'publisher' => ['name' => 'Publisher 1']
                        ],
                        [
                            'id' => '2',
                            'title' => 'Board Game 2',
                            'publisher' => ['name' => 'Publisher 2']
                        ]
                    ];
                    return (array_merge($books, $boardGames)); //, array_merge $boardGames
                }
            ]
        ]
    ]),
    'types' => [$bookType, $boardGameType]
]);

/*
query {
    libraryItems {
        ... on BoardGame {
        id
        title
            publisher {
                name
            }
        }
        ... on Book {
        id
        title
            authors {
                firstName
            }
        }
    }
}
*/