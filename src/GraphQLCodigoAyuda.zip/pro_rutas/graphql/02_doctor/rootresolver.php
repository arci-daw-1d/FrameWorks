<?php

$root_fileds_Resolver = [
    'getDoctor' => function ($rootValue, array $args) {
        // Lógica para obtener un médico por ID
        return [
            'id' => $args['id'],
            'name' => 'Dr. Smith',
            'specialty' => 'Cardiology',
            'yearsOfExperience' => 10
        ];
    },
    'listDoctors' => function ($rootValue, array $args) {
        // Lógica para listar todos los médicos
        return [
            [
                'id' => '1',
                'name' => 'Dr. Smith',
                'specialty' => 'Cardiology',
                'yearsOfExperience' => 10
            ],
            [
                'id' => '2',
                'name' => 'Dr. Johnson',
                'specialty' => 'Neurology',
                'yearsOfExperience' => 8
            ]
        ];
    },
    'addDoctor' => function ($rootValue, array $args) {
        // Lógica para añadir un nuevo médico
        return [
            'id' => uniqid('', true),
            'name' => $args['name'],
            'specialty' => $args['specialty'],
            'yearsOfExperience' => $args['yearsOfExperience']
        ];
    },
    'updateDoctor' => function ($rootValue, array $args) {
        // Lógica para actualizar la información de un médico
        return [
            'id' => $args['id'],
            'name' => $args['name'] ?? 'Dr. Updated',
            'specialty' => $args['specialty'] ?? 'Updated Specialty',
            'yearsOfExperience' => $args['yearsOfExperience'] ?? 0
        ];
    },
    'deleteDoctor' => function ($rootValue, array $args) {
        // Lógica para eliminar un médico por ID
        return true;
    }
];